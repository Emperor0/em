﻿D7 BLACKCORE v2.2.0 - FRAME LAB
- Automatically acquires the official PresentMon console binary from GameTechDev when measurement needs it.
- Verifies the release SHA256 against D7's online tool catalog before execution.
- 3-second measurement delay + 30-second gameplay capture.
- PresentMon v2 metrics, dropped-frame exclusion, same-game A/B comparison.
- KEEP / ROLLBACK / INCONCLUSIVE measurement verdict.
- No CPU voltage, RAM timings, GPU OC, MSI mode, affinity or network offload changes are applied by this release.
