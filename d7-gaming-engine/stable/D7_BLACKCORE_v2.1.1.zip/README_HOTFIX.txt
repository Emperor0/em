﻿D7 BLACKCORE v2.1.1
Responsive BLACKSCAN hotfix.
Fixes the freeze caused by recursively scanning Program Files once per tool.
Tool detection now uses known paths, PATH, installed-app registry entries and scheduled-task executable paths.
BLACKSCAN yields UI events between expensive inventory stages.
