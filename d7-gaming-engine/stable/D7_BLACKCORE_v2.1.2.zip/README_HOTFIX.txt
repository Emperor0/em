﻿D7 BLACKCORE v2.1.2
Learn Game hotfix.
Fixes the runtime "finally is not recognized" error.
Replaces the foreground-window interop with valid C# DllImport code.
Learn Game now reports success/failure cleanly and always restores the D7 window.
