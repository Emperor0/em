﻿D7 BLACKCORE v2.1
Measurement-first release.
New: deep tool detection, PresentMon integration when available, frametime/1%/0.1% analysis, stability event audit, MSI/interrupt read-only audit, network advanced-property audit, A/B comparison.
This release does NOT automatically change interrupt affinity, MSI mode, network offloads, BIOS, RAM timings, CPU voltage, or GPU overclock.
