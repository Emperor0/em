﻿D7 BLACKCORE v2.1.3 - clean runtime-safety rebuild; fixes .DisplayName measurement crash, preserves Learn Game, adds single-instance protection and guarded measurement errors.
