from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, as_completed
from .models import StepResult,Evidence
class SwarmEngine:
    def __init__(self,llm,max_workers:int=4): self.llm=llm; self.max_workers=max(2,max_workers)
    def run_council(self,goal:str,roles:list[str]) -> StepResult:
        if not self.llm.available(): return StepResult(False,'AI provider unavailable for swarm',error='LLM_UNAVAILABLE')
        def one(role):
            system=f'You are the {role} specialist in D7 BLACKCORE. Analyze independently. Be concrete, evidence-aware, and concise.'
            return role,self.llm.chat(system,goal)
        outputs={}
        with ThreadPoolExecutor(max_workers=min(self.max_workers,len(roles))) as ex:
            futs=[ex.submit(one,r) for r in roles]
            for f in as_completed(futs):
                role,text=f.result(); outputs[role]=text
        synthesis=self.llm.chat('You are BLACKCORE Master Judge. Synthesize the specialists into one executable answer. Resolve conflicts and list uncertainties.',
                                goal+'\n\n'+'\n\n'.join(f'[{r}]\n{t}' for r,t in outputs.items()))
        return StepResult(True,f'Swarm completed with {len(outputs)} specialists',[Evidence('specialists',str(len(outputs))),Evidence('synthesis_chars',str(len(synthesis)))],{'outputs':outputs,'text':synthesis})
