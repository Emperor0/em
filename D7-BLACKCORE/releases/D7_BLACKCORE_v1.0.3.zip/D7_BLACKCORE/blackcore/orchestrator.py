from __future__ import annotations
from typing import Callable
from .models import Mission, MissionStatus, RiskLevel, StepResult, Evidence
from .planner import Planner
from .quality import QualityEngine
from .safety import SafetyPolicy
from .system_operator import SystemOperator
from .browser_operator import BrowserOperator
from .memory import MemoryStore
from .skills import SkillRegistry
from .llm import LLMProvider
from .legacy import D7GovernorAdapter
from .updater import UpdateManager
from .health import HealthManager
from .desktop_operator import DesktopOperator
from .swarm import SwarmEngine
from .skill_academy import SkillAcademy
from .departments import DepartmentHub
from .audit import AuditLog
from .recovery import RecoveryManager

class Blackcore:
    def __init__(self, settings):
        settings.ensure_dirs(); self.settings=settings; data=settings.expanded_data_dir()
        self.memory=MemoryStore(data/'memory'/'blackcore.db'); self.skills=SkillRegistry(data/'skills')
        self.system=SystemOperator(data/'workspace'); self.desktop=DesktopOperator(data)
        self.browser=BrowserOperator(data/'browser_profile',settings.browser_headless,settings.max_browser_retries)
        self.llm=LLMProvider(settings.llm_base_url,settings.llm_api_key,settings.llm_model, settings.llm_provider_type, settings.llm_auto_start, settings.opencode_executable)
        self.swarm=SwarmEngine(self.llm,settings.swarm_workers); self.departments=DepartmentHub(self.swarm)
        self.academy=SkillAcademy(data/'skills',self.llm,self.memory); self.recovery=RecoveryManager(data)
        self.audit=AuditLog(data/'logs'/'audit.jsonl'); self.governor=D7GovernorAdapter(); self.planner=Planner()
        self.safety=SafetyPolicy(); self.quality=QualityEngine(settings.quality_target); self.updater=UpdateManager(settings)
        self.health=HealthManager(self); self.cancelled=False

    def create_mission(self, goal:str, mode:str|None=None)->Mission: return self.planner.plan(goal,mode or self.settings.default_mode,self.settings.quality_target)

    def _reason(self,agent:str,goal:str)->StepResult:
        if not self.llm.available(): return StepResult(False,f'{agent} needs an AI model provider. Start/configure OpenCode or another supported AI provider.',error='LLM_UNAVAILABLE')
        text=self.llm.chat(f'You are {agent}, a specialist inside D7 BLACKCORE. Be executable, factual, concise. Never claim actions without evidence.',goal)
        return StepResult(True,f'{agent} completed reasoning',[Evidence('model_output_chars',str(len(text)))],{'text':text})

    def _execute_step(self,step)->StepResult:
        a=step.action
        if a=='search_web': return self.browser.search_google(step.args['query'])
        if a=='open_url':
            r=self.browser.open(step.args['url']); return r if r.ok else self.system.execute('open_url',url=step.args['url'])
        if a=='research':
            topic=step.args.get('topic',''); br=self.browser.search_google(topic)
            if not br.ok: br=self.system.execute('search_web',query=topic)
            if self.llm.available():
                rr=self.departments.run('research',topic); rr.evidence.extend(br.evidence); return rr
            return br
        if a=='reason': return self._reason(step.agent,step.args.get('goal',''))
        if a=='department': return self.departments.run(step.args.get('department','general'),step.args.get('goal',''))
        if a=='learn_skill': return self.academy.learn(step.args.get('name','skill'),step.args.get('objective',''))
        if a=='quality_review': return StepResult(True,'Independent quality checkpoint reached',[Evidence('quality_target',str(self.settings.quality_target)),Evidence('policy','evidence-first')])
        if a.startswith('system:'): return self.system.execute(a.split(':',1)[1],**step.args)
        if a.startswith('desktop:'):
            fn=getattr(self.desktop,a.split(':',1)[1],None)
            return fn(**step.args) if fn else StepResult(False,'Unknown desktop action',error='NO_EXECUTOR')
        if a=='checkpoint_file': return self.recovery.checkpoint_file(step.args['path'])
        if a=='restore_checkpoint': return self.recovery.restore(step.args['checkpoint_dir'])
        return StepResult(False,f'No executor for {a}',error='NO_EXECUTOR')

    def run(self,mission:Mission,log:Callable[[str],None]|None=None,approval:Callable[[object],bool]|None=None)->Mission:
        log=log or (lambda _:None); self.cancelled=False; mission.status=MissionStatus.RUNNING; self.memory.save_run(mission); self.audit.write('mission_started',id=mission.id,goal=mission.goal,mode=mission.mode)
        reports=[]
        for idx,step in enumerate(mission.steps,1):
            if self.cancelled: mission.status=MissionStatus.CANCELLED; break
            step.risk=self.safety.classify(step.action,step.args)
            if step.risk==RiskLevel.BLOCKED:
                step.status=MissionStatus.FAILED; step.result=StepResult(False,'Blocked by safety policy',error='BLOCKED'); mission.status=MissionStatus.FAILED; break
            if step.risk==RiskLevel.APPROVAL:
                mission.status=MissionStatus.WAITING_APPROVAL
                if not approval or not approval(step): step.status=MissionStatus.CANCELLED; mission.status=MissionStatus.CANCELLED; break
                mission.status=MissionStatus.RUNNING
            step.status=MissionStatus.RUNNING; log(f'[{idx}/{len(mission.steps)}] {step.agent}: {step.name}')
            try: result=self._execute_step(step)
            except Exception as e: result=StepResult(False,f'{step.name} crashed',error=f'{type(e).__name__}: {e}')
            step.result=result; report=self.quality.evaluate_step(result); reports.append(report); step.status=MissionStatus.PASSED if result.ok else MissionStatus.FAILED
            self.audit.write('step_finished',mission_id=mission.id,step=step.name,agent=step.agent,ok=result.ok,score=report.score,error=result.error)
            log(f"    {'PASS' if result.ok else 'FAIL'} — {result.summary} — quality {report.score:.1f}")
            self.memory.save_run(mission)
            if not result.ok: mission.status=MissionStatus.FAILED; break
        if mission.status==MissionStatus.RUNNING:
            final=self.quality.evaluate_mission(reports); mission.final_score=final.score; mission.status=MissionStatus.PASSED if final.passed else MissionStatus.FAILED; log(f'MISSION {mission.status.value} — score {final.score:.1f}/{mission.quality_target:.1f}')
        self.memory.save_run(mission); self.audit.write('mission_finished',id=mission.id,status=mission.status.value,score=mission.final_score); return mission

    def stop(self): self.cancelled=True; self.audit.write('stop_requested')
