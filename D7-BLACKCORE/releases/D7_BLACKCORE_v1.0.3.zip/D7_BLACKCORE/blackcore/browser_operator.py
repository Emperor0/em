from __future__ import annotations
from pathlib import Path
from urllib.parse import quote_plus
import time
from .models import StepResult, Evidence

class BrowserOperator:
    """Visible persistent browser with bounded self-healing retries.

    Credentials are intentionally entered by the user in the visible browser session.
    BLACKCORE reuses that browser profile instead of storing passwords itself.
    """
    def __init__(self, profile_dir: str | Path, headless: bool = False, max_retries: int = 2):
        self.profile_dir = str(profile_dir)
        self.headless = headless
        self.max_retries = max(0, min(int(max_retries), 5))
        self._pw = self._ctx = self._page = None

    def start(self) -> StepResult:
        self.close()
        try:
            from playwright.sync_api import sync_playwright
            self._pw = sync_playwright().start()
            self._ctx = self._pw.chromium.launch_persistent_context(
                self.profile_dir, headless=self.headless, viewport={"width": 1440, "height": 900}
            )
            self._page = self._ctx.pages[0] if self._ctx.pages else self._ctx.new_page()
            return StepResult(True, "Browser operator started", [Evidence("profile", self.profile_dir), Evidence("mode", "visible" if not self.headless else "headless")])
        except Exception as e:
            self.close()
            return StepResult(False, "Playwright browser unavailable", error=str(e))

    def ensure(self) -> StepResult | None:
        try:
            if self._page is not None and not self._page.is_closed(): return None
        except Exception:
            pass
        r = self.start()
        return None if r.ok else r

    def _navigate(self, url: str, summary: str) -> StepResult:
        last = None
        for attempt in range(self.max_retries + 1):
            err = self.ensure()
            if err: last = err.error or err.summary
            else:
                try:
                    self._page.goto(url, wait_until="domcontentloaded", timeout=30_000)
                    return StepResult(True, summary, [Evidence("url", self._page.url), Evidence("title", self._page.title()), Evidence("attempt", str(attempt+1))])
                except Exception as e:
                    last = str(e)
            if attempt < self.max_retries:
                self.close(); time.sleep(min(1.5, 0.35 * (attempt + 1)))
        return StepResult(False, "Browser navigation failed after self-healing retries", error=str(last))

    def search_google(self, query: str) -> StepResult:
        return self._navigate(f"https://www.google.com/search?q={quote_plus(query)}", f"Searched Google: {query}")

    def open(self, url: str) -> StepResult:
        return self._navigate(url, f"Opened {url}")

    def close(self):
        try:
            if self._ctx: self._ctx.close()
        except Exception: pass
        try:
            if self._pw: self._pw.stop()
        except Exception: pass
        self._ctx = self._page = self._pw = None
