from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json, os, sys, shutil, time

APP_NAME = "D7 BLACKCORE"
APP_VERSION = "1.0.3"
ROOT = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parents[1]
DEFAULT_DATA_DIR = Path(os.environ.get("LOCALAPPDATA", str(ROOT / "data"))) / "D7BLACKCORE"
DEFAULT_SETTINGS_PATH = DEFAULT_DATA_DIR / "blackcore.settings.json"
DEFAULT_UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/Emperor0/em/main/D7-BLACKCORE/releases/update.json"

@dataclass
class Settings:
    data_dir: str = str(DEFAULT_DATA_DIR)
    quality_target: float = 95.0
    default_mode: str = "ELITE"
    llm_base_url: str = "http://127.0.0.1:8082"
    llm_provider_type: str = "auto"
    llm_auto_start: bool = True
    opencode_executable: str = ""
    llm_api_key: str = ""
    llm_model: str = ""
    browser_engine: str = "playwright"
    browser_headless: bool = False
    max_browser_retries: int = 2
    require_approval_for_send: bool = True
    require_approval_for_delete: bool = True
    require_approval_for_publish: bool = True
    update_manifest_url: str = DEFAULT_UPDATE_MANIFEST_URL
    update_channel: str = "alpha"
    auto_check_updates: bool = True
    update_timeout_seconds: int = 15
    self_heal_enabled: bool = True
    swarm_workers: int = 4
    desktop_control_enabled: bool = True

    @classmethod
    def load(cls, path: Path | None = None) -> "Settings":
        path = path or DEFAULT_SETTINGS_PATH
        defaults = asdict(cls())
        path.parent.mkdir(parents=True, exist_ok=True)
        # One-time migration from early builds that stored settings beside the app.
        legacy = ROOT / "blackcore.settings.json"
        if not path.exists() and legacy.exists():
            try:
                shutil.copy2(legacy, path)
            except Exception:
                pass
        if not path.exists():
            s = cls(); s.save(path); return s
        try:
            data = json.loads(path.read_text(encoding="utf-8-sig"))
        except Exception:
            try:
                shutil.copy2(path, path.with_name(path.name + f".corrupt.{int(time.time())}.bak"))
            except Exception:
                pass
            data = {}
        # Ignore unknown legacy/future keys instead of failing the whole app.
        merged = {**defaults, **{k:v for k,v in data.items() if k in defaults}}
        return cls(**merged)

    def save(self, path: Path | None = None):
        path = path or DEFAULT_SETTINGS_PATH
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), indent=2, ensure_ascii=False), encoding="utf-8")

    def expanded_data_dir(self) -> Path:
        return Path(os.path.expandvars(self.data_dir)).expanduser()

    def ensure_dirs(self):
        p = self.expanded_data_dir()
        for sub in ["memory", "logs", "browser_profile", "workspace", "snapshots", "skills", "updates", "screenshots", "checkpoints"]:
            (p / sub).mkdir(parents=True, exist_ok=True)
