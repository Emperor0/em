# D7 BLACKCORE 1.0.3

نسخة عربية RTL بواجهة حديثة، OpenCode Native Provider، تنفيذ محلي موثّق، وتحديث مباشر من GitHub داخل التطبيق.

## الجديد في 1.0.3
- واجهة عربية RTL حديثة بالكامل.
- زر «تحديث الآن» يفحص GitHub وينزّل ويتحقق ويثبّت الإصدار الجديد من داخل BLACKCORE.
- عرض حالة خطوات المهمة حيًا بدل بقاء الخطوات PENDING بصريًا.
- Fast Path لمهام الملفات المحلية البسيطة: إنشاء مجلد/كتابة ملف/قراءة تحقق بدون إرسال المهمة إلى Swarm بلا داعٍ.
- OpenCode auto-start وNative health/session integration.
- SHA-256 + staging + backup + rollback للتحديثات.

البيانات الحساسة والذاكرة والجلسات تبقى تحت `%LOCALAPPDATA%\D7BLACKCORE` ولا تُضمّن في GitHub Releases.
