@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" call INSTALL_AND_RUN.bat
".venv\Scripts\python.exe" -m pip install pyinstaller
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --windowed --name "D7 BLACKCORE" --collect-all PySide6 --collect-all pyautogui --collect-all PIL main.py
if not exist "dist\D7 BLACKCORE\D7 BLACKCORE.exe" goto :fail
mkdir "dist\D7 BLACKCORE\tools" 2>nul
copy /Y "tools\update_worker.ps1" "dist\D7 BLACKCORE\tools\update_worker.ps1" >nul
copy /Y "blackcore.settings.json" "dist\D7 BLACKCORE\blackcore.settings.json" >nul
copy /Y "START_HERE_AR.txt" "dist\D7 BLACKCORE\START_HERE_AR.txt" >nul
echo EXE built: dist\D7 BLACKCORE\D7 BLACKCORE.exe
pause
exit /b 0
:fail
echo Build failed.
pause
exit /b 1
