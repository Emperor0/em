from __future__ import annotations
import json, threading
from PySide6.QtCore import Signal, QObject, QTimer, Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QLabel,QPushButton,QPlainTextEdit,
    QLineEdit,QComboBox,QProgressBar,QFrame,QTableWidget,QTableWidgetItem,QHeaderView,QMessageBox,
    QTabWidget,QTextEdit,QCheckBox,QGraphicsDropShadowEffect
)
from blackcore import APP_NAME, APP_VERSION
from blackcore.updater import is_newer

class Bus(QObject):
    log = Signal(str)
    done = Signal(object)
    update_checked = Signal(object)
    update_progress = Signal(int)
    update_prepared = Signal(object)
    health_done = Signal(object)
    repair_done = Signal(object)
    approval_requested = Signal(object)

STYLE = r"""
* { font-family:'Segoe UI Variable','Segoe UI'; font-size:13px; }
QMainWindow, QWidget { background:#07090d; color:#f4f7fb; }
QFrame#card, QFrame#hero { background:#0d1118; border:1px solid #1c2635; border-radius:18px; }
QFrame#hero { background:#0a0f17; border:1px solid #263448; }
QLabel#brand { font-size:28px; font-weight:800; letter-spacing:1px; }
QLabel#title { font-size:22px; font-weight:800; }
QLabel#muted { color:#8c99aa; }
QLabel#eyebrow { color:#8c99aa; font-size:11px; font-weight:700; }
QLabel#metric { font-size:25px; font-weight:800; }
QLabel#good { color:#66e3a4; font-weight:800; }
QLabel#warn { color:#ffd27a; font-weight:800; }
QLabel#bad { color:#ff7685; font-weight:800; }
QPushButton { background:#121a25; color:#eef3f9; border:1px solid #28364a; border-radius:11px; padding:10px 16px; font-weight:700; }
QPushButton:hover { background:#192435; border-color:#3a506c; }
QPushButton:pressed { background:#0d141e; }
QPushButton:disabled { color:#5f6b79; background:#0c1016; border-color:#171e29; }
QPushButton#primary { background:#e8eef7; color:#07090d; border:none; padding:11px 19px; }
QPushButton#primary:hover { background:#ffffff; }
QPushButton#accent { background:#10233a; border:1px solid #2d6fa7; color:#cceaff; }
QPushButton#danger { background:#2a1118; border:1px solid #6a2633; color:#ffbac3; }
QPushButton#good { background:#10261a; border:1px solid #2d7248; color:#9af2bc; }
QLineEdit,QPlainTextEdit,QTextEdit,QComboBox,QTableWidget { background:#090d13; border:1px solid #1d2939; border-radius:12px; padding:9px; selection-background-color:#23496c; }
QLineEdit:focus,QPlainTextEdit:focus,QTextEdit:focus,QComboBox:focus { border:1px solid #3c6f9d; }
QHeaderView::section { background:#0f1621; color:#9daabd; border:0; padding:10px; font-weight:700; }
QTableWidget { gridline-color:#131b26; }
QProgressBar { background:#090d13; border:1px solid #1d2939; border-radius:7px; text-align:center; min-height:13px; }
QProgressBar::chunk { background:#7db8e8; border-radius:6px; }
QTabWidget::pane { border:0; }
QTabBar::tab { background:#0b1017; color:#8f9bad; padding:11px 18px; margin-left:4px; border:1px solid #151e2a; border-radius:10px; font-weight:700; }
QTabBar::tab:selected { background:#172131; color:#ffffff; border-color:#2d4058; }
QCheckBox { spacing:8px; }
"""

class MainWindow(QMainWindow):
    def __init__(self, core):
        super().__init__(); self.core=core; self.bus=Bus(); self.current=None; self._checked_update=None
        self._quick_update_requested=False
        self.setWindowTitle(f"{APP_NAME} — {APP_VERSION}"); self.resize(1420,900); self.setMinimumSize(1080,700); self.setStyleSheet(STYLE)
        QApplication.instance().setLayoutDirection(Qt.RightToLeft)
        self.bus.log.connect(self.append_log); self.bus.done.connect(self.mission_done)
        self.bus.update_checked.connect(self._on_update_checked); self.bus.update_progress.connect(self._on_update_progress)
        self.bus.update_prepared.connect(self._on_update_prepared); self.bus.health_done.connect(self._on_health_done)
        self.bus.repair_done.connect(self._on_repair_done); self.bus.approval_requested.connect(self._on_approval_requested)
        self._build(); self._refresh_status(); self._show_last_update_result()
        self.timer=QTimer(self); self.timer.timeout.connect(self._tick); self.timer.start(700)
        if self.core.settings.auto_check_updates and self.core.settings.update_manifest_url:
            QTimer.singleShot(1100, self.check_updates)
        QTimer.singleShot(450, self.scan_health)

    @staticmethod
    def shadow(widget):
        sh=QGraphicsDropShadowEffect(widget); sh.setBlurRadius(26); sh.setOffset(0,7); sh.setColor(QColor(0,0,0,110)); widget.setGraphicsEffect(sh)

    def card(self,title,value="—",subtitle=""):
        f=QFrame(); f.setObjectName("card"); self.shadow(f); l=QVBoxLayout(f); l.setContentsMargins(18,14,18,14); l.setSpacing(3)
        a=QLabel(title); a.setObjectName("eyebrow"); b=QLabel(value); b.setObjectName("metric"); l.addWidget(a); l.addWidget(b)
        if subtitle:
            s=QLabel(subtitle); s.setObjectName("muted"); l.addWidget(s)
        return f,b

    def _build(self):
        root=QWidget(); self.setCentralWidget(root); outer=QVBoxLayout(root); outer.setContentsMargins(24,20,24,22); outer.setSpacing(15)

        top=QHBoxLayout(); top.setSpacing(12)
        brand=QVBoxLayout(); title=QLabel("D7 BLACKCORE"); title.setObjectName("brand"); sub=QLabel(f"نظام العمليات الذكي الخاص • الإصدار {APP_VERSION} • تنفيذ موثّق بالأدلة"); sub.setObjectName("muted"); brand.addWidget(title); brand.addWidget(sub); top.addLayout(brand); top.addStretch()
        self.update_badge=QLabel("جاري فحص التحديث"); self.update_badge.setObjectName("good"); top.addWidget(self.update_badge)
        self.quick_update=QPushButton("تحديث الآن"); self.quick_update.setObjectName("accent"); self.quick_update.clicked.connect(self.quick_update_action); top.addWidget(self.quick_update)
        self.mode=QComboBox(); self.mode.addItems(["TURBO","ELITE","OBSESSION"]); self.mode.setCurrentText(self.core.settings.default_mode); top.addWidget(self.mode)
        stop=QPushButton("إيقاف"); stop.setObjectName("danger"); stop.clicked.connect(self.core.stop); top.addWidget(stop); outer.addLayout(top)

        grid=QGridLayout(); grid.setHorizontalSpacing(12)
        self.c_state,self.v_state=self.card("حالة المهمة","جاهز","يتغير لحظيًا أثناء التنفيذ")
        self.c_score,self.v_score=self.card("هدف الجودة",str(self.core.settings.quality_target),"بوابة قبول قابلة للقياس")
        self.c_model,self.v_model=self.card("محرك الذكاء","جاري الفحص","OpenCode / مزود متوافق")
        self.c_governor,self.v_governor=self.card("D7 GOVERNOR","جاري الفحص","إدارة حالة الجهاز")
        for i,c in enumerate([self.c_state,self.c_score,self.c_model,self.c_governor]): grid.addWidget(c,0,i)
        outer.addLayout(grid)

        cmdframe=QFrame(); cmdframe.setObjectName("hero"); self.shadow(cmdframe); cl=QVBoxLayout(cmdframe); cl.setContentsMargins(18,16,18,16); cl.setSpacing(10)
        head=QHBoxLayout(); h=QVBoxLayout(); lbl=QLabel("المهمة"); lbl.setObjectName("title"); hint=QLabel("اكتب الهدف بشكل طبيعي، وBLACKCORE يختار أسرع مسار تنفيذ ويثبت النتيجة."); hint.setObjectName("muted"); h.addWidget(lbl); h.addWidget(hint); head.addLayout(h); head.addStretch(); cl.addLayout(head)
        self.command=QPlainTextEdit(); self.command.setLayoutDirection(Qt.RightToLeft); self.command.setPlaceholderText("مثال: أنشئ مجلد على سطح المكتب باسم BLACKCORE_TEST وداخله ملف result.txt واكتب فيه: D7 BLACKCORE WORKS ثم تحقق من المحتوى.\nأو: دور لي عن فرص ربح حقيقية في تصميم المواقع وقدّم تقرير بالأدلة."); self.command.setMaximumHeight(120); cl.addWidget(self.command)
        row=QHBoxLayout(); self.runbtn=QPushButton("تنفيذ المهمة"); self.runbtn.setObjectName("primary"); self.runbtn.clicked.connect(self.run_mission); row.addWidget(self.runbtn); self.planbtn=QPushButton("الخطة فقط"); self.planbtn.clicked.connect(self.plan_only); row.addWidget(self.planbtn); row.addStretch(); cl.addLayout(row); outer.addWidget(cmdframe)

        self.tabs=QTabWidget(); self.tabs.setDocumentMode(True); outer.addWidget(self.tabs,1)
        ops=QWidget(); ol=QHBoxLayout(ops); ol.setContentsMargins(0,8,0,0); ol.setSpacing(12)
        left=QVBoxLayout(); left.addWidget(QLabel("سجل التنفيذ الحي")); self.logbox=QPlainTextEdit(); self.logbox.setReadOnly(True); self.logbox.setLayoutDirection(Qt.RightToLeft); left.addWidget(self.logbox); self.progress=QProgressBar(); self.progress.setRange(0,100); left.addWidget(self.progress); ol.addLayout(left,2)
        right=QVBoxLayout(); right.addWidget(QLabel("خطوات المهمة")); self.steps=QTableWidget(0,4); self.steps.setHorizontalHeaderLabels(["الوكيل","الخطوة","الإجراء","الحالة"]); self.steps.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch); self.steps.verticalHeader().setVisible(False); right.addWidget(self.steps); ol.addLayout(right,3); self.tabs.addTab(ops,"العمليات")

        mem=QWidget(); ml=QVBoxLayout(mem); mr=QHBoxLayout(); self.memq=QLineEdit(); self.memq.setPlaceholderText("ابحث في ذاكرة BLACKCORE..."); mbtn=QPushButton("بحث"); mbtn.clicked.connect(self.search_memory); mr.addWidget(self.memq); mr.addWidget(mbtn); ml.addLayout(mr); self.memout=QTextEdit(); self.memout.setReadOnly(True); ml.addWidget(self.memout); self.tabs.addTab(mem,"الذاكرة")

        sysw=QWidget(); sl=QVBoxLayout(sysw); self.systemout=QTextEdit(); self.systemout.setReadOnly(True); sl.addWidget(self.systemout); refresh=QPushButton("تحديث حالة الجهاز"); refresh.clicked.connect(self._refresh_status); sl.addWidget(refresh); self.tabs.addTab(sysw,"النظام")

        skills=QWidget(); skl=QVBoxLayout(skills); self.skillsout=QTextEdit(); self.skillsout.setReadOnly(True); skl.addWidget(self.skillsout); self.tabs.addTab(skills,"المهارات"); self.skillsout.setPlainText(json.dumps(self.core.skills.all(),ensure_ascii=False,indent=2))
        self._build_capabilities_tab(); self._build_update_tab(); self._build_health_tab()

    def _build_capabilities_tab(self):
        page=QWidget(); lay=QVBoxLayout(page)
        title=QLabel("القدرات ومزود الذكاء"); title.setObjectName("title"); lay.addWidget(title)
        sub=QLabel("التحكم المحلي يعمل على جهازك، وأقسام الذكاء تستخدم OpenCode تلقائيًا أو أي مزود متوافق تضيفه."); sub.setObjectName("muted"); lay.addWidget(sub)
        card=QFrame(); card.setObjectName("card"); c=QGridLayout(card)
        c.addWidget(QLabel("عنوان مزود الذكاء"),0,0); self.ai_url=QLineEdit(self.core.settings.llm_base_url); c.addWidget(self.ai_url,0,1)
        c.addWidget(QLabel("النموذج (فارغ = تلقائي)"),1,0); self.ai_model=QLineEdit(self.core.settings.llm_model); c.addWidget(self.ai_model,1,1)
        c.addWidget(QLabel("API Key (اختياري)"),2,0); self.ai_key=QLineEdit(self.core.settings.llm_api_key); self.ai_key.setEchoMode(QLineEdit.Password); c.addWidget(self.ai_key,2,1)
        save=QPushButton("حفظ إعدادات الذكاء"); save.clicked.connect(self.save_ai_provider); c.addWidget(save,3,1); lay.addWidget(card)
        actions=QHBoxLayout(); shot=QPushButton("التقاط الشاشة"); shot.clicked.connect(self.capture_screen); actions.addWidget(shot); openws=QPushButton("فتح مساحة العمل"); openws.clicked.connect(lambda:self.core.system.execute("open_path",path=str(self.core.settings.expanded_data_dir()/"workspace"))); actions.addWidget(openws); actions.addStretch(); lay.addLayout(actions)
        self.capout=QTextEdit(); self.capout.setReadOnly(True); lay.addWidget(self.capout,1); self.refresh_capabilities(); self.tabs.addTab(page,"القدرات")

    def _build_update_tab(self):
        page=QWidget(); self.update_page=page; lay=QVBoxLayout(page); lay.setSpacing(12)
        head=QHBoxLayout(); a=QVBoxLayout(); title=QLabel("مركز التحديث عبر الإنترنت"); title.setObjectName("title"); a.addWidget(title); info=QLabel("تنزيل مباشر • تحقق SHA-256 • نسخة احتياطية • استرجاع تلقائي عند فشل التحديث • بياناتك المحلية محفوظة"); info.setObjectName("muted"); a.addWidget(info); head.addLayout(a); head.addStretch(); self.update_version=QLabel(f"الإصدار الحالي {APP_VERSION}"); self.update_version.setObjectName("good"); head.addWidget(self.update_version); lay.addLayout(head)
        card=QFrame(); card.setObjectName("card"); c=QVBoxLayout(card); self.update_url=QLineEdit(self.core.settings.update_manifest_url); self.update_url.setVisible(False)
        r=QHBoxLayout(); self.update_channel=QComboBox(); self.update_channel.addItems(["alpha","beta","stable"]); self.update_channel.setCurrentText(self.core.settings.update_channel); r.addWidget(QLabel("القناة")); r.addWidget(self.update_channel); self.auto_updates=QCheckBox("فحص تلقائي عند تشغيل BLACKCORE"); self.auto_updates.setChecked(self.core.settings.auto_check_updates); r.addWidget(self.auto_updates); save=QPushButton("حفظ"); save.clicked.connect(self.save_update_settings); r.addWidget(save); r.addStretch(); c.addLayout(r); lay.addWidget(card)
        action=QHBoxLayout(); self.checkbtn=QPushButton("فحص التحديثات"); self.checkbtn.clicked.connect(self.check_updates); action.addWidget(self.checkbtn); self.installbtn=QPushButton("تنزيل وتثبيت التحديث"); self.installbtn.setObjectName("primary"); self.installbtn.setEnabled(False); self.installbtn.clicked.connect(self.install_update); action.addWidget(self.installbtn); action.addStretch(); lay.addLayout(action)
        self.update_progress=QProgressBar(); self.update_progress.setRange(0,100); lay.addWidget(self.update_progress)
        self.update_status=QTextEdit(); self.update_status.setReadOnly(True); self.update_status.setLayoutDirection(Qt.RightToLeft); self.update_status.setPlainText("BLACKCORE سيفحص GitHub تلقائيًا. عندما يتوفر إصدار جديد ستقدر تحدث من هنا بدون تنزيل ملفات يدويًا."); lay.addWidget(self.update_status,1); self.tabs.addTab(page,"التحديث")

    def _build_health_tab(self):
        page=QWidget(); lay=QVBoxLayout(page); a=QVBoxLayout(); title=QLabel("الصحة والإصلاح الذاتي"); title.setObjectName("title"); a.addWidget(title); sub=QLabel("يفحص النواة، الذاكرة، المتطلبات، OpenCode، المتصفح وسجل الأعطال."); sub.setObjectName("muted"); a.addWidget(sub); lay.addLayout(a)
        buttons=QHBoxLayout(); self.scanbtn=QPushButton("فحص الآن"); self.scanbtn.clicked.connect(self.scan_health); buttons.addWidget(self.scanbtn); self.repairbtn=QPushButton("إصلاح المشاكل القابلة للإصلاح"); self.repairbtn.setObjectName("good"); self.repairbtn.clicked.connect(self.repair_health); buttons.addWidget(self.repairbtn); buttons.addStretch(); lay.addLayout(buttons)
        self.healthout=QTextEdit(); self.healthout.setReadOnly(True); self.healthout.setLayoutDirection(Qt.RightToLeft); lay.addWidget(self.healthout,1); self.tabs.addTab(page,"الصحة")

    def append_log(self,s): self.logbox.appendPlainText(s)

    def plan_only(self):
        goal=self.command.toPlainText().strip()
        if not goal: return
        m=self.core.create_mission(goal,self.mode.currentText()); self.current=m; self._show_steps(m); self.append_log(f"خطة {m.id[:8]} — {len(m.steps)} خطوات")

    @staticmethod
    def status_ar(value):
        return {"PENDING":"بانتظار التنفيذ","RUNNING":"قيد التنفيذ","WAITING_APPROVAL":"بانتظار الموافقة","PASSED":"مكتمل","FAILED":"فشل","CANCELLED":"ملغي"}.get(str(value),str(value))

    def _show_steps(self,m):
        self.steps.setRowCount(len(m.steps))
        for r,s in enumerate(m.steps):
            vals=[s.agent,s.name,s.action,self.status_ar(s.status.value)]
            for c,v in enumerate(vals): self.steps.setItem(r,c,QTableWidgetItem(str(v)))

    def run_mission(self):
        goal=self.command.toPlainText().strip()
        if not goal: return
        self.current=self.core.create_mission(goal,self.mode.currentText()); self._show_steps(self.current); self.runbtn.setEnabled(False); self.v_state.setText("قيد التنفيذ"); self.progress.setValue(3); self.logbox.clear()
        def approval(step):
            import threading as _threading
            gate={"step":step,"event":_threading.Event(),"approved":False}; self.bus.approval_requested.emit(gate); gate["event"].wait(); return bool(gate["approved"])
        def work():
            m=self.core.run(self.current,log=self.bus.log.emit,approval=approval); self.bus.done.emit(m)
        threading.Thread(target=work,daemon=True).start()

    def _on_approval_requested(self,gate):
        step=gate["step"]
        ans=QMessageBox.question(self,"موافقة مطلوبة",f"BLACKCORE يطلب الإذن لتنفيذ:\n\n{step.name}\nالإجراء: {step.action}\n\nهل توافق؟")
        gate["approved"]=ans==QMessageBox.StandardButton.Yes; gate["event"].set()

    def mission_done(self,m):
        self.runbtn.setEnabled(True); self._show_steps(m); self.v_state.setText(self.status_ar(m.status.value)); self.v_score.setText(f"{m.final_score:.1f}" if m.final_score is not None else str(self.core.settings.quality_target)); self.progress.setValue(100 if m.status.value=="PASSED" else 35)

    def search_memory(self):
        rows=self.core.memory.search(self.memq.text().strip() or " "); self.memout.setPlainText(json.dumps(rows,ensure_ascii=False,indent=2))

    def _tick(self):
        if self.current:
            self._show_steps(self.current); self.v_state.setText(self.status_ar(self.current.status.value))
            total=max(1,len(self.current.steps)); done=sum(1 for s in self.current.steps if s.status.value in ("PASSED","FAILED","CANCELLED"));
            if self.current.status.value=="RUNNING": self.progress.setValue(max(3,int(done/total*92)))
        # Slow status refresh every ~5 seconds without blocking UI on the provider probe.
        if not hasattr(self,"_ticks"): self._ticks=0
        self._ticks+=1
        if self._ticks%7==0: self._refresh_status()

    def _refresh_status(self):
        if not self.current or self.current.status.value not in ("RUNNING","WAITING_APPROVAL"):
            if not self.current: self.v_state.setText("جاهز")
        self.v_score.setText(str(self.core.settings.quality_target) if not self.current or self.current.final_score is None else f"{self.current.final_score:.1f}")
        online=self.core.llm.cached_available(); self.v_model.setText("متصل" if online else "غير متصل"); self.v_model.setObjectName("metric")
        gov=self.core.governor.status(); self.v_governor.setText(gov.data.get("state","متصل") if gov.ok else "غير موجود")
        snap=self.core.system.system_snapshot(); self.systemout.setPlainText(json.dumps(snap,ensure_ascii=False,indent=2))

    def save_ai_provider(self):
        self.core.settings.llm_base_url=self.ai_url.text().strip(); self.core.settings.llm_model=self.ai_model.text().strip(); self.core.settings.llm_api_key=self.ai_key.text().strip(); self.core.settings.save()
        from blackcore.llm import LLMProvider
        self.core.llm=LLMProvider(self.core.settings.llm_base_url,self.core.settings.llm_api_key,self.core.settings.llm_model,self.core.settings.llm_provider_type,self.core.settings.llm_auto_start,self.core.settings.opencode_executable)
        self.core.swarm.llm=self.core.llm; self.core.academy.llm=self.core.llm; self.capout.append("\nتم حفظ مزود الذكاء دون تغيير الذاكرة."); QTimer.singleShot(100,self.scan_health)

    def capture_screen(self):
        r=self.core.desktop.screenshot(); self.capout.append("\n"+(r.summary if r.ok else f"فشل: {r.error}"))

    def refresh_capabilities(self):
        local="جاهز" if self.core.desktop.available() else "يحتاج متطلب"
        lines=["مصفوفة قدرات BLACKCORE","",f"مشغّل سطح المكتب: {local}","مشغّل المتصفح: جاهز","الذاكرة الدائمة: جاهزة","Swarm / الأقسام: جاهزة عند اتصال الذكاء","أكاديمية المهارات: جاهزة","الاسترجاع ونقاط الحفظ: جاهزة","سجل التدقيق: جاهز","التحديث والاسترجاع: جاهز","","الأقسام: أبحاث • برمجة • يوتيوب • إيرادات • تصميم • المجلس العام"]
        self.capout.setPlainText("\n".join(lines))

    def save_update_settings(self):
        # Manifest URL is application-managed. Users only choose channel/auto-check.
        self.core.settings.update_channel=self.update_channel.currentText(); self.core.settings.auto_check_updates=self.auto_updates.isChecked(); self.core.settings.save(); self.update_status.append("\nتم حفظ إعدادات التحديث.")

    def quick_update_action(self):
        self.tabs.setCurrentWidget(self.update_page)
        if self._checked_update and is_newer(self._checked_update.version,APP_VERSION):
            self.install_update()
        else:
            self._quick_update_requested=True
            self.check_updates()

    def check_updates(self):
        self.save_update_settings(); self.checkbtn.setEnabled(False); self.installbtn.setEnabled(False); self.quick_update.setEnabled(False); self.update_progress.setValue(5); self.update_status.setPlainText("جاري فحص أحدث إصدار عبر الإنترنت...")
        def work():
            available,msg,info=self.core.updater.check(self.core.settings.update_manifest_url); self.bus.update_checked.emit({"available":available,"message":msg,"info":info})
        threading.Thread(target=work,daemon=True).start()

    def _on_update_checked(self,payload):
        self.checkbtn.setEnabled(True); self.quick_update.setEnabled(True); self.update_progress.setValue(15); info=payload.get("info"); self._checked_update=info
        available=bool(payload.get("available") and info and is_newer(info.version,APP_VERSION))
        if available:
            text=f"يتوفر تحديث جديد: {info.version}\nالقناة: {info.channel}\nتاريخ النشر: {info.published_at or '—'}\n\n{info.notes or 'لا توجد ملاحظات.'}\n\nاضغط «تنزيل وتثبيت التحديث»."
        elif info:
            text=f"BLACKCORE محدث. أحدث إصدار متاح: {info.version}."
        else:
            text="تعذر فحص التحديثات. تحقق من الإنترنت وحاول مرة أخرى.\n\n"+payload.get("message","")
        self.update_status.setPlainText(text); self.installbtn.setEnabled(available); self.update_badge.setText(f"تحديث {info.version} متاح" if available else "محدّث" if info else "تعذر الفحص"); self.quick_update.setText("ثبّت التحديث" if available else "فحص التحديث")
        if not available: self.update_progress.setValue(0)
        if available and self._quick_update_requested:
            self._quick_update_requested=False
            QTimer.singleShot(120, self.install_update)
        elif not available:
            self._quick_update_requested=False

    def install_update(self):
        info=self._checked_update
        if not info:
            self.check_updates(); return
        self.installbtn.setEnabled(False); self.checkbtn.setEnabled(False); self.quick_update.setEnabled(False); self.update_progress.setValue(1); self.update_status.append("\nجاري تنزيل الحزمة والتحقق من SHA-256...")
        def work():
            try:
                stage=self.core.updater.prepare(info,progress=self.bus.update_progress.emit); self.bus.update_prepared.emit({"ok":True,"stage":stage,"info":info})
            except Exception as e: self.bus.update_prepared.emit({"ok":False,"error":str(e),"info":info})
        threading.Thread(target=work,daemon=True).start()

    def _on_update_progress(self,n): self.update_progress.setValue(max(0,min(int(n),100)))

    def _on_update_prepared(self,payload):
        self.checkbtn.setEnabled(True); self.quick_update.setEnabled(True)
        if not payload.get("ok"):
            self.installbtn.setEnabled(True); self.update_progress.setValue(0); self.update_status.append("\nفشل التنزيل/التحقق: "+payload.get("error","خطأ غير معروف")); return
        self.update_progress.setValue(97); info=payload["info"]; stage=payload["stage"]
        ans=QMessageBox.question(self,"تثبيت التحديث",f"تم تنزيل وتحقق الإصدار {info.version}.\n\nسيأخذ BLACKCORE نسخة احتياطية، يغلق نفسه، يحدّث الملفات ثم يعيد التشغيل. إذا فشل سيسترجع النسخة السابقة تلقائيًا.\n\nتثبيت الآن؟")
        if ans != QMessageBox.StandardButton.Yes:
            self.installbtn.setEnabled(True); self.update_status.append("\nتم إلغاء التثبيت؛ الحزمة بقيت في منطقة التجهيز."); return
        ok,msg=self.core.updater.apply_after_exit(info,stage); self.update_status.append("\n"+msg)
        if ok:
            self.update_progress.setValue(100); QTimer.singleShot(500,QApplication.instance().quit)
        else:
            self.installbtn.setEnabled(True); self.update_progress.setValue(0); QMessageBox.critical(self,"تعذر بدء التحديث",msg)

    def _show_last_update_result(self):
        r=self.core.updater.latest_result()
        if not r: return
        phase=r.get("phase","UNKNOWN"); msg=r.get("message",""); self.update_status.append(f"\n\nنتيجة آخر تحديث: {phase}\n{msg}"); self.update_badge.setText("تم التحديث" if r.get("ok") and phase=="APPLIED" else phase)

    def scan_health(self):
        self.scanbtn.setEnabled(False); self.healthout.setPlainText("جاري فحص BLACKCORE...")
        def work(): self.bus.health_done.emit(self.core.health.scan())
        threading.Thread(target=work,daemon=True).start()

    def _on_health_done(self,checks):
        self.scanbtn.setEnabled(True); bad=sum(1 for c in checks if not c.ok); lines=[f"D7 BLACKCORE {APP_VERSION} — {'سليم' if bad==0 else f'{bad} مشكلة مكتشفة'}",""]
        for c in checks:
            mark="نجاح" if c.ok else "فشل"; repair=" • قابل للإصلاح" if c.repairable and not c.ok else ""; lines.append(f"[{mark}] {c.name}: {c.detail}{repair}")
        self.healthout.setPlainText("\n".join(lines)); ai=next((c for c in checks if c.name=="AI provider"),None)
        if ai: self.v_model.setText("متصل" if ai.ok else "غير متصل")

    def repair_health(self):
        ans=QMessageBox.question(self,"إصلاح BLACKCORE","هل تريد إصلاح المشاكل القابلة للإصلاح الآن؟\n\nقد يعيد تثبيت متطلبات Python/Playwright ويحفظ نسخة من قاعدة ذاكرة تالفة قبل إعادة بنائها. لن يحذف ذاكرتك السليمة أو إعداداتك.")
        if ans != QMessageBox.StandardButton.Yes: return
        self.repairbtn.setEnabled(False); self.scanbtn.setEnabled(False); self.healthout.append("\n\nجاري الإصلاح...")
        def work(): self.bus.repair_done.emit(self.core.health.repair())
        threading.Thread(target=work,daemon=True).start()

    def _on_repair_done(self,result):
        self.repairbtn.setEnabled(True); self.scanbtn.setEnabled(True); lines=["اكتمل الإصلاح" if result.get("ok") else "انتهى الإصلاح مع أخطاء"]; lines += ["+ "+x for x in result.get("actions",[])]; lines += ["! "+x for x in result.get("errors",[])]; self.healthout.append("\n\n"+"\n".join(lines)); QTimer.singleShot(400,self.scan_health)
