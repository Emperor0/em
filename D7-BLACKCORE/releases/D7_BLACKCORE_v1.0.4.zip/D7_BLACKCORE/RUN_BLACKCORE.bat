@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  call INSTALL_AND_RUN.bat
  exit /b
)
start "D7 BLACKCORE" ".venv\Scripts\pythonw.exe" "%~dp0main.py"
