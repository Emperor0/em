from __future__ import annotations
import gc,json,tempfile,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from blackcore.config import Settings,APP_VERSION
from blackcore.orchestrator import Blackcore

def main():
    results=[]
    def check(name,fn):
        try: fn(); results.append({'name':name,'ok':True})
        except Exception as e: results.append({'name':name,'ok':False,'error':f'{type(e).__name__}: {e}'})
    # Windows can briefly keep SQLite/WAL handles alive after a health probe.
    # ignore_cleanup_errors prevents a successful preflight from being reported as failed
    # only because the temporary test directory could not be deleted immediately.
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as d:
        s=Settings(data_dir=d,llm_base_url='http://127.0.0.1:9/v1',auto_check_updates=False)
        c=Blackcore(s)
        check('memory',lambda: (c.memory.remember('selftest','x',{'ok':1}), (_ for _ in ()).throw(AssertionError()) if c.memory.recall('selftest','x')['ok']!=1 else None))
        check('planner',lambda: (_ for _ in ()).throw(AssertionError()) if not c.create_mission('build an app').steps else None)
        check('audit',lambda: c.audit.write('self_test'))
        p=Path(d)/'file.txt'; p.write_text('before')
        def recovery():
            cp=c.recovery.checkpoint_file(str(p)); assert cp.ok; p.write_text('after'); rr=c.recovery.restore(cp.evidence[0].value); assert rr.ok and p.read_text()=='before'
        check('recovery',recovery)
        check('system_snapshot',lambda: (_ for _ in ()).throw(AssertionError()) if 'platform' not in c.system.system_snapshot() else None)
        check('desktop_operator',lambda: (_ for _ in ()).throw(AssertionError()) if not c.desktop.shots.exists() else None)
        checks=c.health.scan(); check('health_engine',lambda: (_ for _ in ()).throw(AssertionError()) if len(checks)<8 else None)
        # Release runtime objects before TemporaryDirectory cleanup on Windows.
        try: c.browser.close()
        except Exception: pass
        del c
        gc.collect()
    out={'version':APP_VERSION,'passed':sum(x['ok'] for x in results),'total':len(results),'results':results}
    print(json.dumps(out,ensure_ascii=False,indent=2)); return 0 if out['passed']==out['total'] else 1
if __name__=='__main__': raise SystemExit(main())
