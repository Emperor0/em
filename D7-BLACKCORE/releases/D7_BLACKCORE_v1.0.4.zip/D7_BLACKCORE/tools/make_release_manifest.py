from pathlib import Path
import argparse, hashlib, json, datetime

p=argparse.ArgumentParser()
p.add_argument("zip")
p.add_argument("--version", required=True)
p.add_argument("--url", required=True)
p.add_argument("--channel", default="alpha")
p.add_argument("--notes", default="")
p.add_argument("--out", default="update.json")
a=p.parse_args()
path=Path(a.zip)
h=hashlib.sha256(path.read_bytes()).hexdigest()
obj={"version":a.version,"channel":a.channel,"published_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"download_url":a.url,"sha256":h,"notes":a.notes}
Path(a.out).write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding="utf-8")
print(json.dumps(obj,indent=2,ensure_ascii=False))
