param(
  [Parameter(Mandatory=$true)][int]$ParentPid,
  [Parameter(Mandatory=$true)][string]$Source,
  [Parameter(Mandatory=$true)][string]$Target,
  [Parameter(Mandatory=$true)][string]$Backup,
  [Parameter(Mandatory=$true)][string]$RestartExe,
  [string]$RestartArgs = "",
  [Parameter(Mandatory=$true)][string]$ResultFile,
  [string]$ExpectedVersion = ""
)
$ErrorActionPreference = "Stop"

function Write-Result([bool]$ok, [string]$message, [string]$phase) {
  $obj = [ordered]@{
    ok = $ok; message = $message; phase = $phase; expectedVersion = $ExpectedVersion;
    at = (Get-Date).ToUniversalTime().ToString("o"); backup = $Backup
  }
  $dir = Split-Path -Parent $ResultFile
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  $obj | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 $ResultFile
}

function Copy-Code([string]$From, [string]$To) {
  New-Item -ItemType Directory -Force -Path $To | Out-Null
  $args = @($From, $To, "/E", "/R:2", "/W:1", "/NFL", "/NDL", "/NJH", "/NJS", "/NP",
    "/XD", ".venv", "build", "dist", "__pycache__", ".git",
    "/XF", "blackcore.settings.json")
  & robocopy @args | Out-Null
  if ($LASTEXITCODE -ge 8) { throw "robocopy failed with code $LASTEXITCODE" }
}

try {
  $deadline = (Get-Date).AddSeconds(120)
  while ((Get-Process -Id $ParentPid -ErrorAction SilentlyContinue) -and ((Get-Date) -lt $deadline)) {
    Start-Sleep -Milliseconds 350
  }
  if (Get-Process -Id $ParentPid -ErrorAction SilentlyContinue) {
    throw "BLACKCORE did not exit within 120 seconds"
  }

  if (-not (Test-Path (Join-Path $Source "main.py"))) { throw "Staged update missing main.py" }
  if (-not (Test-Path (Join-Path $Source "blackcore\config.py"))) { throw "Staged update missing blackcore/config.py" }

  New-Item -ItemType Directory -Force -Path $Backup | Out-Null
  Copy-Code $Target $Backup
  Write-Result $true "Backup completed" "BACKUP"

  # Replace code directories to avoid stale modules while preserving .venv and user settings.
  foreach ($name in @("blackcore", "ui", "tools")) {
    $p = Join-Path $Target $name
    if (Test-Path $p) { Remove-Item -Recurse -Force $p }
  }
  Copy-Code $Source $Target

  if (-not (Test-Path (Join-Path $Target "main.py"))) { throw "Post-update verification: main.py missing" }
  if (-not (Test-Path (Join-Path $Target "blackcore\updater.py"))) { throw "Post-update verification: updater.py missing" }
  Write-Result $true "Update applied and verified" "APPLIED"

  if (Test-Path $RestartExe) {
    if ([string]::IsNullOrWhiteSpace($RestartArgs)) { Start-Process -FilePath $RestartExe | Out-Null }
    else { Start-Process -FilePath $RestartExe -ArgumentList ('"' + $RestartArgs + '"') | Out-Null }
  }
  exit 0
}
catch {
  $msg = $_.Exception.Message
  try {
    if (Test-Path $Backup) {
      foreach ($name in @("blackcore", "ui", "tools")) {
        $p = Join-Path $Target $name
        if (Test-Path $p) { Remove-Item -Recurse -Force $p }
      }
      Copy-Code $Backup $Target
      Write-Result $false ("Update failed and rollback completed: " + $msg) "ROLLED_BACK"
    } else {
      Write-Result $false ("Update failed before backup: " + $msg) "FAILED"
    }
  } catch {
    Write-Result $false ("Update failed; rollback also failed: " + $msg + " / " + $_.Exception.Message) "ROLLBACK_FAILED"
  }
  try {
    if (Test-Path $RestartExe) {
      if ([string]::IsNullOrWhiteSpace($RestartArgs)) { Start-Process -FilePath $RestartExe | Out-Null }
      else { Start-Process -FilePath $RestartExe -ArgumentList ('"' + $RestartArgs + '"') | Out-Null }
    }
  } catch {}
  exit 1
}
