@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title D7 BLACKCORE 1.0 Installer
where py >nul 2>&1
if %errorlevel%==0 (set "PY=py") else (set "PY=python")
%PY% --version >nul 2>&1
if errorlevel 1 (
  echo Python 3.11+ is required.
  echo Install Python from python.org and enable Add Python to PATH, then run this file again.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo [1/5] Creating isolated BLACKCORE environment...
  %PY% -m venv .venv || goto :fail
)
echo [2/5] Installing/verifying dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
".venv\Scripts\python.exe" -m pip install -r requirements.txt || goto :fail
echo [3/5] Installing/verifying browser engine...
".venv\Scripts\python.exe" -m playwright install chromium || echo WARNING: Chromium install failed. Health Center can retry later.
echo [4/5] Running BLACKCORE preflight self-test...
".venv\Scripts\python.exe" "%~dp0tools\self_test.py" > "%TEMP%\d7_blackcore_selftest.txt" 2>&1
if errorlevel 1 (
  type "%TEMP%\d7_blackcore_selftest.txt"
  echo.
  echo Preflight failed. BLACKCORE was NOT launched with a broken core.
  pause
  exit /b 1
)
echo [5/5] Launching D7 BLACKCORE 1.0...
start "D7 BLACKCORE" ".venv\Scripts\pythonw.exe" "%~dp0main.py"
exit /b 0
:fail
echo.
echo BLACKCORE installation failed. The application was not launched partially.
pause
exit /b 1
