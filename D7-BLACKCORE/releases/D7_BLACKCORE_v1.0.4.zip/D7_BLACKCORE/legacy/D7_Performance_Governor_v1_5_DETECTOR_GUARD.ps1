﻿#requires -version 5.1
<#
D7 PERFORMANCE GOVERNOR v1.5
Universal automatic GAME / STREAM_GAME / STREAM / IDLE tuning for Windows 10.
Built for low-latency gaming + OBS + TikTok LIVE Studio on one PC.

Design principles:
- Reversible: backup + restore.
- No Defender/Firewall/Windows Update disabling.
- No HPET/BCD timer hacks.
- No TCP/Nagle registry hacks.
- No RAM "cleaner" loops.
- No Realtime process priorities.
- No CPU/GPU overclock or voltage changes in this core build.
#>

param(
    [ValidateSet("Menu","Install","Run","Analyze","Restore","Uninstall")]
    [string]$Mode = "Menu",
    [switch]$HiddenWorker
)

$ErrorActionPreference = "SilentlyContinue"
$Base = Join-Path $env:ProgramData "D7PerformanceGovernor"
$InstalledScript = Join-Path $Base "D7_Performance_Governor_v1.ps1"
$GamesFile = Join-Path $Base "games.json"
$BackupFile = Join-Path $Base "backup.json"
$ConfigFile = Join-Path $Base "config.json"
$StatusFile = Join-Path $Base "status.json"
$LogFile = Join-Path $Base "performance.csv"
$TaskName = "D7 Performance Governor"
New-Item -ItemType Directory -Force -Path $Base | Out-Null

function Is-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Require-Admin {
    if (-not (Is-Admin)) {
        Write-Host "Administrator rights are required." -ForegroundColor Red
        Write-Host "Run the BAT launcher or PowerShell as Administrator."
        Read-Host "Press Enter"
        exit 1
    }
}

function Get-RegValue($Path,$Name) {
    try { return (Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop).$Name } catch { return $null }
}
function Set-Dword($Path,$Name,$Value) {
    New-Item -Path $Path -Force | Out-Null
    New-ItemProperty -Path $Path -Name $Name -PropertyType DWord -Value ([int]$Value) -Force | Out-Null
}
function Set-String($Path,$Name,$Value) {
    New-Item -Path $Path -Force | Out-Null
    Set-ItemProperty -Path $Path -Name $Name -Value ([string]$Value) -Force
}
function Restore-Reg($Path,$Name,$Value,$Type="DWord") {
    New-Item -Path $Path -Force | Out-Null
    if ($null -eq $Value) {
        Remove-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue
    } else {
        if ($Type -eq "String") {
            Set-ItemProperty -Path $Path -Name $Name -Value ([string]$Value) -Force
        } else {
            New-ItemProperty -Path $Path -Name $Name -PropertyType DWord -Value ([int]$Value) -Force | Out-Null
        }
    }
}
function Get-ActivePowerGuid {
    $txt = (powercfg /GETACTIVESCHEME) -join " "
    if ($txt -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') {
        return $matches[1]
    }
    return $null
}
function Get-HagsState {
    $v = Get-RegValue "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" "HwSchMode"
    if ($v -eq 2) { return "ON" }
    if ($v -eq 1) { return "OFF" }
    return "DEFAULT"
}
function Get-DefaultGateway {
    try {
        return (Get-NetRoute -DestinationPrefix "0.0.0.0/0" |
            Sort-Object RouteMetric,InterfaceMetric |
            Select-Object -First 1 -ExpandProperty NextHop)
    } catch { return $null }
}
function Ping-Ms($Target) {
    if (-not $Target) { return $null }
    try {
        $r = Test-Connection -ComputerName $Target -Count 1 -ErrorAction Stop | Select-Object -First 1
        if ($r.PSObject.Properties.Name -contains "ResponseTime") { return [int]$r.ResponseTime }
        if ($r.PSObject.Properties.Name -contains "Latency") { return [int]$r.Latency }
    } catch {}
    return $null
}
function Get-NvidiaStats {
    $obj = [ordered]@{
        Gpu=0; Temp=$null; VramUsed=$null; VramTotal=$null; Clock=$null; Encoder=$null; Power=$null
    }
    $smi = Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue
    if (-not $smi) { return [pscustomobject]$obj }
    try {
        $q = & $smi.Source --query-gpu=utilization.gpu,temperature.gpu,memory.used,memory.total,clocks.gr,utilization.encoder,power.draw --format=csv,noheader,nounits 2>$null
        if ($q) {
            $a = ($q -split ",").Trim()
            if ($a.Count -ge 7) {
                $obj.Gpu = [int][double]$a[0]
                $obj.Temp = [int][double]$a[1]
                $obj.VramUsed = [int][double]$a[2]
                $obj.VramTotal = [int][double]$a[3]
                $obj.Clock = [int][double]$a[4]
                $obj.Encoder = [int][double]$a[5]
                $obj.Power = [math]::Round([double]$a[6],1)
            }
        }
    } catch {}
    return [pscustomobject]$obj
}
function Get-SystemCpu {
    try { return [math]::Round((Get-Counter '\Processor(_Total)\% Processor Time').CounterSamples.CookedValue,1) } catch { return $null }
}
function Get-RamPercent {
    try {
        $os = Get-CimInstance Win32_OperatingSystem
        $used = $os.TotalVisibleMemorySize - $os.FreePhysicalMemory
        return [math]::Round(($used / $os.TotalVisibleMemorySize)*100,1)
    } catch { return $null }
}

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class D7Win32 {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
}
"@

function Get-ForegroundProcess {
    try {
        $h = [D7Win32]::GetForegroundWindow()
        [uint32]$processId = 0
        [void][D7Win32]::GetWindowThreadProcessId($h,[ref]$processId)
        if ($processId -gt 0) { return Get-Process -Id $processId -ErrorAction Stop }
    } catch {}
    return $null
}

function Get-Config {
    if (-not (Test-Path $ConfigFile)) {
        $cfg = [ordered]@{
            PollSeconds = 3
            LogSeconds = 15
            GameHoldSeconds = 25
            GameDetectGpuThreshold = 18
            GpuSaturationThreshold = 95
            GpuSaturationSamples = 3

            # Adaptive CPU/RAM pressure guard. This changes scheduling precedence,
            # not clocks/voltage/affinity, and restores temporary priority changes.
            CpuGuardEnabled = $true
            CpuGuardHigh = 90
            CpuGuardCritical = 96
            CpuGuardRelease = 84
            CpuGuardEnterSamples = 3
            CpuGuardExitSamples = 4
            RamGuardHigh = 86
            AutoCloseCaptureOverlays = $true

            StreamProcesses = @("obs64","obs32")
            StreamCoreProcesses = @("MediaSDK_Server")
            CpuGuardBackground = @(
                "steam","steamwebhelper","Discord","chrome","msedge","firefox",
                "NVIDIA App","nvcontainer","fdm","OneDrive","SearchApp","SearchHost",
                "MicrosoftEdgeUpdate","GoogleUpdate","AdobeARM","AdobeIPCBroker",
                "CCXProcess","Creative Cloud","Teams","ms-teams"
            )
            TikTokNameHints = @("TikTok","LIVE Studio")
            StreamNeverGameRegex = "(?i)^(obs64|obs32|TikTok LIVE Studio|MediaSDK_Server|Streamlabs OBS|Streamlabs Desktop|XSplit|PRISMLiveStudio)$"
            NeverGameProcessRegex = "(?i)^(cua-driver|cua_driver|D7Agent|D7_Agent|python|pythonw|node|code|devenv|powershell|pwsh|cmd|WindowsTerminal)$"
            NeverGamePathRegex = "(?i)(\\AppData\\Local\\Programs\\Cua\\|\\D7Agent\\|\\D7_Agent\\)"
            IgnoreForeground = @(
                "explorer","SearchApp","SearchUI","StartMenuExperienceHost","ShellExperienceHost",
                "ApplicationFrameHost","SystemSettings","Taskmgr","powershell","pwsh","cmd",
                "WindowsTerminal","msedge","chrome","firefox","Discord","steam","steamwebhelper",
                "Battle.net","Agent","EpicGamesLauncher","RiotClientServices","RiotClientUx",
                "EADesktop","EALauncher","Origin","UbisoftConnect","upc","GalaxyClient",
                "RockstarService","Launcher","XboxPcApp","GamingServices","NVIDIA Overlay",
                "NVIDIA Share","nvcontainer","TextInputHost","SecurityHealthSystray"
            )
            LauncherNameRegex = "(?i)(launcher|bootstrap|updater|update|patcher|crashreport|crashpad|easyanticheat|eac|battle\.net|steamwebhelper|epicgameslauncher|riotclient|eadesktop|origin|ubisoftconnect|galaxyclient|rockstarservice|gamingservices)"
            GamePathRegex = "(?i)(\\steamapps\\common\\|\\xboxgames\\|\\windowsapps\\|\\epic games\\|\\gog games\\|\\ea games\\|\\origin games\\|\\ubisoft game launcher\\games\\|\\rockstar games\\|\\games\\)"
            GameModuleRegex = "(?i)^(d3d9|d3d10|d3d11|d3d12|dxgi|vulkan-1|unityplayer|gameassembly|ue4|ue5|nvngx_dlss|amd_fidelityfx).*\.dll$"
            LowerPriorityBackground = @(
                "OneDrive","MicrosoftEdgeUpdate","GoogleUpdate","AdobeARM","AdobeIPCBroker",
                "CCXProcess","Creative Cloud","Teams","ms-teams"
            )
        }
        $cfg | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 $ConfigFile
    } else {
        # Upgrade older config.json in place without deleting the user's values.
        $cfg = Get-Content $ConfigFile -Raw | ConvertFrom-Json
        $changed = $false
        $defaults = [ordered]@{
            PollSeconds=3; LogSeconds=15; GameHoldSeconds=25; GameDetectGpuThreshold=18;
            GpuSaturationThreshold=95; GpuSaturationSamples=3;
            CpuGuardEnabled=$true; CpuGuardHigh=90; CpuGuardCritical=96; CpuGuardRelease=84;
            CpuGuardEnterSamples=3; CpuGuardExitSamples=4; RamGuardHigh=86; AutoCloseCaptureOverlays=$true;
            StreamCoreProcesses=@("MediaSDK_Server");
            CpuGuardBackground=@("steam","steamwebhelper","Discord","chrome","msedge","firefox","NVIDIA App","nvcontainer","fdm","OneDrive","SearchApp","SearchHost","MicrosoftEdgeUpdate","GoogleUpdate","AdobeARM","AdobeIPCBroker","CCXProcess","Creative Cloud","Teams","ms-teams");
            StreamNeverGameRegex="(?i)^(obs64|obs32|TikTok LIVE Studio|MediaSDK_Server|Streamlabs OBS|Streamlabs Desktop|XSplit|PRISMLiveStudio)$";
            NeverGameProcessRegex="(?i)^(cua-driver|cua_driver|D7Agent|D7_Agent|python|pythonw|node|code|devenv|powershell|pwsh|cmd|WindowsTerminal)$";
            NeverGamePathRegex="(?i)(\\AppData\\Local\\Programs\\Cua\\|\\D7Agent\\|\\D7_Agent\\)";
            LauncherNameRegex="(?i)(launcher|bootstrap|updater|update|patcher|crashreport|crashpad|easyanticheat|eac|battle\.net|steamwebhelper|epicgameslauncher|riotclient|eadesktop|origin|ubisoftconnect|galaxyclient|rockstarservice|gamingservices)";
            GamePathRegex="(?i)(\\steamapps\\common\\|\\xboxgames\\|\\windowsapps\\|\\epic games\\|\\gog games\\|\\ea games\\|\\origin games\\|\\ubisoft game launcher\\games\\|\\rockstar games\\|\\games\\)";
            GameModuleRegex="(?i)^(d3d9|d3d10|d3d11|d3d12|dxgi|vulkan-1|unityplayer|gameassembly|ue4|ue5|nvngx_dlss|amd_fidelityfx).*\.dll$"
        }
        foreach ($k in $defaults.Keys) {
            if (-not ($cfg.PSObject.Properties.Name -contains $k)) {
                $cfg | Add-Member -NotePropertyName $k -NotePropertyValue $defaults[$k]
                $changed = $true
            }
        }
        if ($changed) { $cfg | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 $ConfigFile }
    }
    return Get-Content $ConfigFile -Raw | ConvertFrom-Json
}

function Find-TikTokProcesses {
    $found = @()
    foreach ($p in Get-Process -ErrorAction SilentlyContinue) {
        $text = "$($p.ProcessName) $($p.MainWindowTitle)"
        if ($text -match "TikTok" -or $text -match "LIVE Studio") { $found += $p }
    }
    return $found
}
function Find-OBSProcesses {
    return @(Get-Process obs64,obs32 -ErrorAction SilentlyContinue)
}

function Get-ProcessExePath($p) {
    if (-not $p) { return "" }
    try { return [string]$p.Path } catch {}
    try { return [string](Get-CimInstance Win32_Process -Filter "ProcessId=$($p.Id)" -ErrorAction Stop).ExecutablePath } catch {}
    return ""
}

function Test-StreamingProcess($p,$cfg) {
    if (-not $p) { return $false }
    $name = [string]$p.ProcessName
    $title = [string]$p.MainWindowTitle
    $text = "$name $title"

    # Never treat the streaming stack as a game, even if it has a 3D window,
    # lives under Program Files, or was accidentally learned by an older build.
    if ($name -in @("obs64","obs32","MediaSDK_Server")) { return $true }
    if ($text -match "(?i)TikTok\s+LIVE\s+Studio") { return $true }
    if ($cfg.StreamNeverGameRegex -and $name -match [string]$cfg.StreamNeverGameRegex) { return $true }
    return $false
}

function Expand-LearnedGameObjects($obj) {
    $out = @()
    if ($null -eq $obj) { return $out }

    foreach ($item in @($obj)) {
        if ($null -eq $item) { continue }

        # Old/broken database wrapper: { value:[...], Count:n }
        if (($item.PSObject.Properties.Name -contains "value") -and $item.value) {
            $out += @(Expand-LearnedGameObjects $item.value)
            continue
        }

        if ($item.PSObject.Properties.Name -contains "processName") {
            $out += $item
        }
    }
    return @($out)
}

function Get-LearnedGames {
    if (-not (Test-Path $GamesFile)) { return @() }
    try {
        $raw = Get-Content $GamesFile -Raw | ConvertFrom-Json
        return @(Expand-LearnedGameObjects $raw)
    } catch {
        return @()
    }
}

function Save-LearnedGames($games) {
    try {
        # -InputObject prevents PowerShell pipeline enumeration from corrupting
        # the JSON structure when the collection contains one/many entries.
        $arr = @($games)
        ConvertTo-Json -InputObject $arr -Depth 8 | Set-Content -Encoding UTF8 $GamesFile
    } catch {}
}

function Test-GameRecordIsInvalid($g,$cfg) {
    if (-not $g) { return $true }
    $n = [string]$g.processName
    $path = [string]$g.exePath
    if (-not $n) { return $true }

    if ($n -in @("obs64","obs32","MediaSDK_Server")) { return $true }
    if ($n -match "(?i)TikTok\s+LIVE\s+Studio") { return $true }
    if ($cfg.StreamNeverGameRegex -and $n -match [string]$cfg.StreamNeverGameRegex) { return $true }
    if ($cfg.NeverGameProcessRegex -and $n -match [string]$cfg.NeverGameProcessRegex) { return $true }
    if ($cfg.NeverGamePathRegex -and $path -match [string]$cfg.NeverGamePathRegex) { return $true }

    if ($n -match "(?i)^(NVIDIA Overlay|NVIDIA App|NVDisplay\.Container|nvcontainer|ScreenClippingHost|fdm|explorer|dwm|Discord|chrome|msedge|firefox|steam|steamwebhelper|SearchApp|TextInputHost)$") {
        return $true
    }

    if ($path -match "(?i)\\TikTok LIVE Studio\\|\\NVIDIA Corporation\\|\\Windows\\SystemApps\\|\\Softdeluxe\\") {
        return $true
    }

    return $false
}

function Clean-LearnedGames($cfg) {
    $games = @(Get-LearnedGames)
    $clean = @()
    $seen = @{}

    foreach ($g in $games) {
        if (Test-GameRecordIsInvalid $g $cfg) { continue }

        $n = [string]$g.processName
        $path = [string]$g.exePath
        $key = ("{0}|{1}" -f $n.ToLowerInvariant(),$path.ToLowerInvariant())

        if ($seen.ContainsKey($key)) {
            # Merge duplicate observations.
            $old = $seen[$key]
            try { $old.seenCount = [int]$old.seenCount + [math]::Max(1,[int]$g.seenCount) } catch {}
            try {
                if ([datetime]$g.lastSeen -gt [datetime]$old.lastSeen) {
                    $old.lastSeen = $g.lastSeen
                    $old.lastReason = $g.lastReason
                }
            } catch {}
            continue
        }

        $copy = [pscustomobject][ordered]@{
            processName = $n
            exePath = $path
            firstSeen = [string]$g.firstSeen
            lastSeen = [string]$g.lastSeen
            seenCount = $(try { [math]::Max(1,[int]$g.seenCount) } catch { 1 })
            lastReason = [string]$g.lastReason
        }
        $seen[$key] = $copy
        $clean += $copy
    }

    Save-LearnedGames $clean
    return @($clean)
}

function Learn-Game($p,$Reason) {
    if (-not $p) { return }
    $cfgLocal = Get-Config
    if (Test-StreamingProcess $p $cfgLocal) { return }
    if (Test-IgnoredProcess $p $cfgLocal) { return }

    $path = Get-ProcessExePath $p
    $games = @(Clean-LearnedGames $cfgLocal)

    $existing = $games | Where-Object {
        $_.processName -ieq $p.ProcessName -and (
            -not $_.exePath -or -not $path -or $_.exePath -ieq $path
        )
    } | Select-Object -First 1

    if ($existing) {
        $existing.lastSeen = (Get-Date).ToString("o")
        $existing.seenCount = [int]$existing.seenCount + 1
        if ($Reason) { $existing.lastReason = $Reason }
    } else {
        $games += [pscustomobject][ordered]@{
            processName=$p.ProcessName
            exePath=$path
            firstSeen=(Get-Date).ToString("o")
            lastSeen=(Get-Date).ToString("o")
            seenCount=1
            lastReason=$Reason
        }
    }
    Save-LearnedGames $games
}

function Test-IgnoredProcess($p,$cfg) {
    if (-not $p) { return $true }
    if (Test-StreamingProcess $p $cfg) { return $true }

    $n = [string]$p.ProcessName
    $path = Get-ProcessExePath $p
    if ($cfg.NeverGameProcessRegex -and $n -match [string]$cfg.NeverGameProcessRegex) { return $true }
    if ($cfg.NeverGamePathRegex -and $path -match [string]$cfg.NeverGamePathRegex) { return $true }
    foreach ($n in @($cfg.IgnoreForeground)) {
        if ($p.ProcessName -ieq [string]$n) { return $true }
    }
    if ($cfg.LauncherNameRegex -and $p.ProcessName -match [string]$cfg.LauncherNameRegex) { return $true }
    if ($p.ProcessName -match "(?i)^(system|idle|registry|services|svchost|lsass|csrss|wininit|winlogon|fontdrvhost|conhost|sihost|dwm)$") { return $true }
    return $false
}

function Test-LearnedGame($p) {
    if (-not $p) { return $false }
    $cfgLocal = Get-Config
    if (Test-StreamingProcess $p $cfgLocal) { return $false }
    $path = Get-ProcessExePath $p
    foreach ($g in @(Get-LearnedGames)) {
        if ($g.processName -ieq $p.ProcessName) {
            if (-not $g.exePath -or -not $path -or $g.exePath -ieq $path) { return $true }
        }
    }
    return $false
}

function Test-GamePath($p,$cfg) {
    $path = Get-ProcessExePath $p
    if (-not $path) { return $false }
    if ($cfg.GamePathRegex -and $path -match [string]$cfg.GamePathRegex) { return $true }
    return $false
}

function Test-GameModules($p,$cfg) {
    if (-not $p -or -not $cfg.GameModuleRegex) { return $false }
    try {
        foreach ($m in $p.Modules) {
            if ($m.ModuleName -match [string]$cfg.GameModuleRegex) { return $true }
        }
    } catch {}
    return $false
}

function Find-RunningGameCandidate($cfg,$GpuPercent) {
    # Used only when foreground detection failed (Alt-Tab, overlay, TikTok settings, etc.).
    # First use learned games (cheap and exact).
    foreach ($g in @(Get-LearnedGames)) {
        foreach ($p in @(Get-Process -Name $g.processName -ErrorAction SilentlyContinue)) {
            if (Test-IgnoredProcess $p $cfg) { continue }
            $path = Get-ProcessExePath $p
            if ($g.exePath -and $path -and $g.exePath -ine $path) { continue }
            if ($p.MainWindowHandle -ne 0) {
                return [pscustomobject][ordered]@{ Found=$true; Process=$p; Reason="LEARNED_RUNNING"; Confidence=92 }
            }
        }
    }

    # Universal fallback for a NEW game that is running but not foreground anymore.
    # Check visible app processes, launcher paths first; graphics modules only as a last resort.
    foreach ($p in @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 })) {
        if (Test-IgnoredProcess $p $cfg) { continue }

        if (Test-GamePath $p $cfg) {
            return [pscustomobject][ordered]@{ Found=$true; Process=$p; Reason="RUNNING_GAME_PATH"; Confidence=88 }
        }
    }

    if ($GpuPercent -ge [int]$cfg.GameDetectGpuThreshold) {
        foreach ($p in @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 })) {
            if (Test-IgnoredProcess $p $cfg) { continue }
            if (Test-GameModules $p $cfg) {
                return [pscustomobject][ordered]@{ Found=$true; Process=$p; Reason="RUNNING_GRAPHICS_ENGINE"; Confidence=82 }
            }
        }
    }

    return [pscustomobject][ordered]@{ Found=$false; Process=$null; Reason=""; Confidence=0 }
}

function Get-GameDetection($Foreground,$cfg,$GpuPercent) {
    $none = [pscustomobject][ordered]@{ Found=$false; Process=$null; Reason=""; Confidence=0 }

    # Primary path: current foreground process. This is drive- and launcher-independent.
    if ($Foreground -and -not (Test-IgnoredProcess $Foreground $cfg)) {
        if (Test-LearnedGame $Foreground) {
            return [pscustomobject][ordered]@{ Found=$true; Process=$Foreground; Reason="LEARNED"; Confidence=100 }
        }
        if (Test-GamePath $Foreground $cfg) {
            return [pscustomobject][ordered]@{ Found=$true; Process=$Foreground; Reason="GAME_PATH"; Confidence=95 }
        }
        if (Test-GameModules $Foreground $cfg) {
            return [pscustomobject][ordered]@{ Found=$true; Process=$Foreground; Reason="GRAPHICS_ENGINE"; Confidence=90 }
        }
        if ($Foreground.MainWindowHandle -ne 0 -and $GpuPercent -ge [int]$cfg.GameDetectGpuThreshold) {
            return [pscustomobject][ordered]@{ Found=$true; Process=$Foreground; Reason="GPU_FOREGROUND"; Confidence=80 }
        }
    }

    # Secondary path: find the real game even after Alt-Tab or if a stream app is foreground.
    $running = Find-RunningGameCandidate $cfg $GpuPercent
    if ($running.Found) { return $running }

    return $none
}

function Save-Backup {
    if (Test-Path $BackupFile) { return }
    $nicPower = @()
    try {
        foreach ($pm in Get-NetAdapterPowerManagement -ErrorAction SilentlyContinue) {
            $nicPower += [ordered]@{
                Name=$pm.Name
                DeviceSleepOnDisconnect="$($pm.DeviceSleepOnDisconnect)"
                SelectiveSuspend="$($pm.SelectiveSuspend)"
                D0PacketCoalescing="$($pm.D0PacketCoalescing)"
            }
        }
    } catch {}
    $state = [ordered]@{
        Timestamp=(Get-Date).ToString("o")
        OriginalPowerGuid=Get-ActivePowerGuid
        D7PowerGuid=$null
        Registry=@{
            GameMode1=Get-RegValue "HKCU:\Software\Microsoft\GameBar" "AutoGameModeEnabled"
            GameMode2=Get-RegValue "HKCU:\Software\Microsoft\GameBar" "AllowAutoGameMode"
            GameDVR1=Get-RegValue "HKCU:\System\GameConfigStore" "GameDVR_Enabled"
            GameDVR2=Get-RegValue "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" "AppCaptureEnabled"
            PowerThrottle=Get-RegValue "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" "PowerThrottlingOff"
            MouseSpeed=Get-RegValue "HKCU:\Control Panel\Mouse" "MouseSpeed"
            MouseT1=Get-RegValue "HKCU:\Control Panel\Mouse" "MouseThreshold1"
            MouseT2=Get-RegValue "HKCU:\Control Panel\Mouse" "MouseThreshold2"
        }
        NicPower=$nicPower
    }
    $state | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 $BackupFile
}
function Update-BackupD7Guid($Guid) {
    if (-not (Test-Path $BackupFile)) { return }
    $b = Get-Content $BackupFile -Raw | ConvertFrom-Json
    $b.D7PowerGuid = $Guid
    $b | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 $BackupFile
}

function New-D7PowerPlan {
    $b = Get-Content $BackupFile -Raw | ConvertFrom-Json
    if ($b.D7PowerGuid) {
        $list = (powercfg /LIST) -join "`n"
        if ($list -match [regex]::Escape([string]$b.D7PowerGuid)) { return [string]$b.D7PowerGuid }
    }

    $orig = Get-ActivePowerGuid
    if (-not $orig) { return $null }
    $out = (powercfg /DUPLICATESCHEME $orig) -join " "
    if ($out -notmatch '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') { return $null }
    $g = $matches[1]
    powercfg /CHANGENAME $g "D7 GAME + STREAM" "Automatic low-latency gaming/stream profile" | Out-Null

    # AC only. Keep max performance without unsafe timer/voltage changes.
    powercfg /SETACVALUEINDEX $g SUB_PROCESSOR PROCTHROTTLEMAX 100 | Out-Null
    powercfg /SETACVALUEINDEX $g SUB_PROCESSOR PROCTHROTTLEMIN 100 | Out-Null
    powercfg /SETACVALUEINDEX $g SUB_PCIEXPRESS ASPM 0 | Out-Null
    powercfg /SETACVALUEINDEX $g SUB_USB USBSELECTIVE 0 | Out-Null
    powercfg /SETACVALUEINDEX $g SUB_DISK DISKIDLE 0 | Out-Null
    powercfg /SETACTIVE $g | Out-Null

    Update-BackupD7Guid $g
    return $g
}

function Apply-Baseline {
    Require-Admin
    Save-Backup
    try {
        Enable-ComputerRestore -Drive "$($env:SystemDrive)\" | Out-Null
        Checkpoint-Computer -Description "D7 Performance Governor" -RestorePointType "MODIFY_SETTINGS" | Out-Null
    } catch {}

    Set-Dword "HKCU:\Software\Microsoft\GameBar" "AutoGameModeEnabled" 1
    Set-Dword "HKCU:\Software\Microsoft\GameBar" "AllowAutoGameMode" 1
    Set-Dword "HKCU:\System\GameConfigStore" "GameDVR_Enabled" 0
    Set-Dword "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" "AppCaptureEnabled" 0
    Set-Dword "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" "PowerThrottlingOff" 1

    # Windows mouse acceleration off. This does not change mouse DPI/polling rate.
    Set-String "HKCU:\Control Panel\Mouse" "MouseSpeed" "0"
    Set-String "HKCU:\Control Panel\Mouse" "MouseThreshold1" "0"
    Set-String "HKCU:\Control Panel\Mouse" "MouseThreshold2" "0"

    try { Enable-MMAgent -MemoryCompression | Out-Null } catch {}

    $g = New-D7PowerPlan

    # Disable NIC sleep/coalescing only where Windows exposes a supported control.
    try {
        foreach ($a in Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object Status -eq "Up") {
            Set-NetAdapterPowerManagement -Name $a.Name -SelectiveSuspend Disabled -DeviceSleepOnDisconnect Disabled -D0PacketCoalescing Disabled -NoRestart -ErrorAction SilentlyContinue
        }
    } catch {}

    return $g
}

function Set-ProcPriority($Processes,$Priority) {
    foreach ($p in $Processes) {
        try { $p.PriorityClass = $Priority } catch {}
    }
}

$script:D7OriginalPriorities = @{}

function Remember-And-SetPriority($Processes,$Priority) {
    foreach ($p in @($Processes)) {
        if (-not $p) { continue }
        try {
            $key = [string]$p.Id
            if (-not $script:D7OriginalPriorities.ContainsKey($key)) {
                $script:D7OriginalPriorities[$key] = [string]$p.PriorityClass
            }
            if ([string]$p.PriorityClass -ne [string]$Priority) {
                $p.PriorityClass = $Priority
            }
        } catch {}
    }
}

function Restore-GuardPriorities {
    foreach ($key in @($script:D7OriginalPriorities.Keys)) {
        try {
            $pidToRestore = [int]$key
            $p = Get-Process -Id $pidToRestore -ErrorAction SilentlyContinue
            if ($p) {
                $orig = [string]$script:D7OriginalPriorities[$key]
                if ($orig) { $p.PriorityClass = $orig }
            }
        } catch {}
    }
    $script:D7OriginalPriorities = @{}
}

function Find-StreamCoreProcesses {
    $out = @()
    foreach ($n in @("MediaSDK_Server")) {
        $out += @(Get-Process -Name $n -ErrorAction SilentlyContinue)
    }
    return @($out)
}

function Get-CpuGuardBackgroundProcesses($cfg) {
    $out = @()
    foreach ($n in @($cfg.CpuGuardBackground)) {
        $out += @(Get-Process -Name ([string]$n) -ErrorAction SilentlyContinue)
    }
    return @($out | Sort-Object Id -Unique)
}

function Stop-CaptureOverlaysIfNeeded($cfg) {
    $actions = @()
    if (-not $cfg.AutoCloseCaptureOverlays) { return $actions }

    foreach ($name in @("discord_clips","NVIDIA Overlay")) {
        foreach ($p in @(Get-Process -Name $name -ErrorAction SilentlyContinue)) {
            try {
                Stop-Process -Id $p.Id -Force -ErrorAction Stop
                $actions += "$($p.ProcessName):$($p.Id)"
            } catch {}
        }
    }
    return @($actions)
}

function Apply-StreamScheduling($obs,$tt,$gameProc,$cfg,$PressureMode) {
    $core = Find-StreamCoreProcesses

    # OBS is tiny in the measured setup but must never miss compositor time.
    Remember-And-SetPriority $obs "AboveNormal"

    # TikTok UI does not need AboveNormal while a game is active; its MediaSDK
    # pipeline is protected separately. This prevents the UI from pre-empting
    # the game during CPU pressure.
    Remember-And-SetPriority $tt "Normal"
    Remember-And-SetPriority $core "AboveNormal"

    # Keep the game at Normal during streaming. Windows already foreground-boosts it.
    if ($gameProc) { Remember-And-SetPriority @($gameProc) "Normal" }

    if ($PressureMode -in @("PRESSURE","CRITICAL","RAM_PRESSURE")) {
        $bg = Get-CpuGuardBackgroundProcesses $cfg
        Remember-And-SetPriority $bg "BelowNormal"
        return @($bg | ForEach-Object { $_.ProcessName } | Sort-Object -Unique)
    }
    return @()
}

function Lower-BackgroundPriority($cfg) {
    foreach ($name in $cfg.LowerPriorityBackground) {
        foreach ($p in Get-Process -Name $name -ErrorAction SilentlyContinue) {
            try { $p.PriorityClass = "BelowNormal" } catch {}
        }
    }
}
function Is-GameCandidate($p,$cfg) {
    if (-not $p) { return $false }
    return (-not (Test-IgnoredProcess $p $cfg))
}

function Write-Status($State,$Game,$GamePid,$GameExe,$DetectReason,$DetectConfidence,$Gpu,$Cpu,$Ram,$GwPing,$NetPing,$SaturationCount,$CpuGuardMode,$CpuGuardSamples,$Restrained,$OverlayActions) {
    $status = [ordered]@{
        time=(Get-Date).ToString("o")
        state=$State
        foregroundGame=$Game
        gamePid=$GamePid
        gameExe=$GameExe
        gameDetectionReason=$DetectReason
        gameDetectionConfidence=$DetectConfidence
        gpuPercent=$Gpu.Gpu
        gpuTempC=$Gpu.Temp
        gpuClockMHz=$Gpu.Clock
        vramUsedMB=$Gpu.VramUsed
        vramTotalMB=$Gpu.VramTotal
        encoderPercent=$Gpu.Encoder
        gpuPowerW=$Gpu.Power
        cpuPercent=$Cpu
        ramPercent=$Ram
        gatewayPingMs=$GwPing
        internetPingMs=$NetPing
        gpuSaturationSamples=$SaturationCount
        cpuGuardMode=$CpuGuardMode
        cpuGuardSamples=$CpuGuardSamples
        restrainedProcesses=@($Restrained)
        overlayGuardActions=@($OverlayActions)
        hags=Get-HagsState
    }
    $status | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 $StatusFile
}
function Append-Log($State,$Game,$Gpu,$Cpu,$Ram,$GwPing,$NetPing) {
    if (-not (Test-Path $LogFile)) {
        "time,state,game,gpu,temp,clock,vramUsed,vramTotal,encoder,power,cpu,ram,gatewayPing,internetPing" | Set-Content -Encoding UTF8 $LogFile
    }
    $safeGame = ($Game -replace ',', '_')
    $line = "{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13}" -f `
        (Get-Date -Format "yyyy-MM-dd HH:mm:ss"),$State,$safeGame,$Gpu.Gpu,$Gpu.Temp,$Gpu.Clock,`
        $Gpu.VramUsed,$Gpu.VramTotal,$Gpu.Encoder,$Gpu.Power,$Cpu,$Ram,$GwPing,$NetPing
    Add-Content -Encoding UTF8 $LogFile $line
}

function Run-Governor {
    Require-Admin
    $cfg = Get-Config
    [void](Clean-LearnedGames $cfg)
    if (-not (Test-Path $BackupFile)) { Apply-Baseline | Out-Null }
    $b = Get-Content $BackupFile -Raw | ConvertFrom-Json
    $d7Guid = [string]$b.D7PowerGuid
    $origGuid = [string]$b.OriginalPowerGuid
    $lastState = ""
    $lastLog = Get-Date "2000-01-01"
    $lastNet = Get-Date "2000-01-01"
    $gwPing = $null
    $netPing = $null
    $sat = 0
    $cpuPressureSamples = 0
    $cpuReleaseSamples = 0
    $cpuGuardMode = "OFF"
    $restrained = @()
    $overlayActions = @()

    $lastGamePid = 0
    $lastGameSeen = Get-Date "2000-01-01"
    $lastGameName = ""
    $lastGameExe = ""
    $lastDetectReason = ""
    $lastDetectConfidence = 0

    while ($true) {
        $obs = Find-OBSProcesses
        $tt = Find-TikTokProcesses
        $gpu = Get-NvidiaStats
        $fg = Get-ForegroundProcess

        $det = Get-GameDetection $fg $cfg $gpu.Gpu
        $gameProc = $null
        $gameCandidate = $false
        $detectReason = ""
        $detectConfidence = 0

        if ($det.Found -and $det.Process) {
            $gameProc = $det.Process
            $gameCandidate = $true
            $detectReason = [string]$det.Reason
            $detectConfidence = [int]$det.Confidence
            $lastGamePid = [int]$gameProc.Id
            $lastGameSeen = Get-Date
            $lastGameName = [string]$gameProc.ProcessName
            $lastGameExe = Get-ProcessExePath $gameProc
            $lastDetectReason = $detectReason
            $lastDetectConfidence = $detectConfidence

            if ($detectReason -notin @("LEARNED","LEARNED_RUNNING")) {
                Learn-Game $gameProc $detectReason
            }
        } elseif ($lastGamePid -gt 0 -and ((Get-Date) - $lastGameSeen).TotalSeconds -le [int]$cfg.GameHoldSeconds) {
            # Hysteresis: keep GAME/STREAM_GAME while briefly Alt-Tabbed or while an overlay is focused.
            $held = Get-Process -Id $lastGamePid -ErrorAction SilentlyContinue
            if ($held) {
                $gameProc = $held
                $gameCandidate = $true
                $detectReason = "HOLD"
                $detectConfidence = [math]::Max(70,$lastDetectConfidence)
            }
        }

        $state = "IDLE"
        if ($obs.Count -gt 0 -and $tt.Count -gt 0 -and $gameCandidate) { $state = "STREAM_GAME" }
        elseif ($obs.Count -gt 0 -and $tt.Count -gt 0) { $state = "STREAM" }
        elseif ($gameCandidate) { $state = "GAME" }

        if ($state -ne $lastState) {
            if ($state -in @("GAME","STREAM_GAME")) {
                if ($d7Guid) { powercfg /SETACTIVE $d7Guid | Out-Null }
            } elseif ($state -eq "IDLE") {
                if ($origGuid) { powercfg /SETACTIVE $origGuid | Out-Null }
            }

            # Leaving a guarded streaming state: restore every temporary priority.
            if ($lastState -in @("STREAM","STREAM_GAME") -and $state -notin @("STREAM","STREAM_GAME")) {
                Restore-GuardPriorities
                $cpuPressureSamples = 0
                $cpuReleaseSamples = 0
                $cpuGuardMode = "OFF"
                $restrained = @()
            }

            if ($state -eq "STREAM") {
                # No game: both apps may run AboveNormal.
                Remember-And-SetPriority $obs "AboveNormal"
                Remember-And-SetPriority $tt "AboveNormal"
                Remember-And-SetPriority (Find-StreamCoreProcesses) "AboveNormal"
                Lower-BackgroundPriority $cfg
            } elseif ($state -eq "STREAM_GAME") {
                # Actual adaptive scheduling occurs every loop after CPU/RAM telemetry.
                Lower-BackgroundPriority $cfg
            } elseif ($state -eq "GAME" -and $gameCandidate -and $gameProc) {
                Restore-GuardPriorities
                try { $gameProc.PriorityClass = "AboveNormal" } catch {}
                Lower-BackgroundPriority $cfg
            }
            $lastState = $state
        }

        $cpu = Get-SystemCpu
        $ram = Get-RamPercent

        $overlayActions = @()
        $restrained = @()

        if ($state -eq "STREAM_GAME") {
            $overlayActions = @(Stop-CaptureOverlaysIfNeeded $cfg)

            if ($cfg.CpuGuardEnabled) {
                $high = [double]$cfg.CpuGuardHigh
                $critical = [double]$cfg.CpuGuardCritical
                $release = [double]$cfg.CpuGuardRelease
                $enterSamples = [int]$cfg.CpuGuardEnterSamples
                $exitSamples = [int]$cfg.CpuGuardExitSamples
                $ramHigh = [double]$cfg.RamGuardHigh

                if ($cpu -ge $high -or $ram -ge $ramHigh) {
                    $cpuPressureSamples++
                    $cpuReleaseSamples = 0
                } elseif ($cpu -le $release -and $ram -lt ($ramHigh - 4)) {
                    $cpuReleaseSamples++
                    if ($cpuReleaseSamples -ge $exitSamples) {
                        $cpuPressureSamples = 0
                    }
                } else {
                    $cpuReleaseSamples = 0
                }

                if ($ram -ge $ramHigh -and $cpuPressureSamples -ge $enterSamples) {
                    $cpuGuardMode = "RAM_PRESSURE"
                } elseif ($cpu -ge $critical -and $cpuPressureSamples -ge $enterSamples) {
                    $cpuGuardMode = "CRITICAL"
                } elseif ($cpuPressureSamples -ge $enterSamples) {
                    $cpuGuardMode = "PRESSURE"
                } else {
                    $cpuGuardMode = "ARMED"
                }

                if ($cpuReleaseSamples -ge $exitSamples) {
                    Restore-GuardPriorities
                    $cpuGuardMode = "ARMED"
                    $cpuReleaseSamples = 0
                }

                $restrained = @(Apply-StreamScheduling $obs $tt $gameProc $cfg $cpuGuardMode)
            } else {
                $cpuGuardMode = "DISABLED"
                $restrained = @(Apply-StreamScheduling $obs $tt $gameProc $cfg "NORMAL")
            }
        } elseif ($state -eq "STREAM") {
            $cpuGuardMode = "STREAM_ONLY"
        } else {
            $cpuGuardMode = "OFF"
            $cpuPressureSamples = 0
            $cpuReleaseSamples = 0
        }

        if ($state -eq "STREAM_GAME" -and $gpu.Gpu -ge [int]$cfg.GpuSaturationThreshold) { $sat++ } else { $sat = 0 }

        if (((Get-Date) - $lastNet).TotalSeconds -ge 30) {
            $gw = Get-DefaultGateway
            $gwPing = Ping-Ms $gw
            $netPing = Ping-Ms "1.1.1.1"
            $lastNet = Get-Date
        }

        if ($gameCandidate -and $gameProc -and (Test-StreamingProcess $gameProc $cfg)) {
            $gameCandidate = $false
            $gameProc = $null
            $detectReason = "STREAM_PROCESS_REJECTED"
            $detectConfidence = 0
            if ($obs.Count -gt 0 -and $tt.Count -gt 0) { $state = "STREAM" }
            else { $state = "IDLE" }
        }

        $gameName = if ($gameCandidate -and $gameProc) { [string]$gameProc.ProcessName } else { "" }
        $gamePid = if ($gameCandidate -and $gameProc) { [int]$gameProc.Id } else { 0 }
        $gameExe = if ($gameCandidate -and $gameProc) { Get-ProcessExePath $gameProc } else { "" }

        Write-Status $state $gameName $gamePid $gameExe $detectReason $detectConfidence $gpu $cpu $ram $gwPing $netPing $sat $cpuGuardMode $cpuPressureSamples $restrained $overlayActions

        if (((Get-Date) - $lastLog).TotalSeconds -ge [int]$cfg.LogSeconds) {
            Append-Log $state $gameName $gpu $cpu $ram $gwPing $netPing
            $lastLog = Get-Date
        }

        Start-Sleep -Seconds ([int]$cfg.PollSeconds)
    }
}

function Analyze-System {
    Require-Admin
    Clear-Host
    $os = Get-CimInstance Win32_OperatingSystem
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $gpuName = (Get-CimInstance Win32_VideoController | Where-Object Name -match "NVIDIA" | Select-Object -First 1).Name
    $gpu = Get-NvidiaStats
    $mem = Get-CimInstance Win32_PhysicalMemory
    Write-Host "=== D7 PERFORMANCE GOVERNOR - ANALYSIS ===" -ForegroundColor Cyan
    Write-Host "OS        : $($os.Caption) / Build $($os.BuildNumber)"
    Write-Host "CPU       : $($cpu.Name)"
    Write-Host "GPU       : $gpuName"
    Write-Host ("RAM       : {0:N1} GB / {1} module(s)" -f ($os.TotalVisibleMemorySize/1MB), @($mem).Count)
    if ($mem) { Write-Host ("RAM Speed : {0} MHz" -f (($mem | Measure-Object Speed -Maximum).Maximum)) }
    Write-Host "Power     : $((powercfg /GETACTIVESCHEME) -join ' ')"
    Write-Host "HAGS      : $(Get-HagsState)"
    try { Write-Host "Mem Compr : $((Get-MMAgent).MemoryCompression)" } catch {}
    Write-Host "GPU now   : $($gpu.Gpu)% / $($gpu.Temp) C / Encoder $($gpu.Encoder)% / VRAM $($gpu.VramUsed)/$($gpu.VramTotal) MB"
    Write-Host "OBS       : $(@(Find-OBSProcesses).Count) process(es)"
    Write-Host "TikTok    : $(@(Find-TikTokProcesses).Count) matching process(es)"
    Write-Host "Gateway   : $(Get-DefaultGateway)"
    Write-Host "Learned   : $(@(Get-LearnedGames).Count) game(s)"
    Write-Host "CPU Guard : Adaptive pressure control enabled by default in STREAM_GAME"
    Write-Host ""
    Write-Host "This build intentionally leaves CPU/GPU clocks and voltages untouched." -ForegroundColor Yellow
    Write-Host "Hardware tuning will be layered on only after the stable baseline is measured."
    Read-Host "Press Enter"
}

function Install-Governor {
    Require-Admin
    Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 600
    Copy-Item -LiteralPath $PSCommandPath -Destination $InstalledScript -Force
    Get-Config | Out-Null
    $g = Apply-Baseline

    $arg = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$InstalledScript`" -Mode Run -HiddenWorker"
    $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $arg
    $trigger = New-ScheduledTaskTrigger -AtLogOn
    $principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Highest
    $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Days 3650)
    Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null

    Start-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    Write-Host "D7 Performance Governor v1.5 installed and started." -ForegroundColor Green
    Write-Host "Auto states: IDLE -> GAME -> STREAM -> STREAM_GAME"
    Write-Host "Universal game detector: foreground + path + graphics engine + learned games + GPU fallback"
    Write-Host "CPU Guard: adaptive stream scheduling + background restraint + capture-overlay guard"
    Write-Host "Detector Guard: rejects local agents/dev tools/stream apps from learned-game database"
    Write-Host "Status: $StatusFile"
    Write-Host "Logs  : $LogFile"
    if ($g) { Write-Host "D7 power plan: $g" }
    Write-Host "Restart Windows once before judging performance." -ForegroundColor Yellow
    Read-Host "Press Enter"
}

function Restore-All {
    Require-Admin
    Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    if (-not (Test-Path $BackupFile)) {
        Write-Host "No backup found." -ForegroundColor Red
        return
    }
    $b = Get-Content $BackupFile -Raw | ConvertFrom-Json

    if ($b.OriginalPowerGuid) { powercfg /SETACTIVE $b.OriginalPowerGuid | Out-Null }
    if ($b.D7PowerGuid) { powercfg /DELETE $b.D7PowerGuid | Out-Null }

    Restore-Reg "HKCU:\Software\Microsoft\GameBar" "AutoGameModeEnabled" $b.Registry.GameMode1
    Restore-Reg "HKCU:\Software\Microsoft\GameBar" "AllowAutoGameMode" $b.Registry.GameMode2
    Restore-Reg "HKCU:\System\GameConfigStore" "GameDVR_Enabled" $b.Registry.GameDVR1
    Restore-Reg "HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR" "AppCaptureEnabled" $b.Registry.GameDVR2
    Restore-Reg "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" "PowerThrottlingOff" $b.Registry.PowerThrottle
    Restore-Reg "HKCU:\Control Panel\Mouse" "MouseSpeed" $b.Registry.MouseSpeed "String"
    Restore-Reg "HKCU:\Control Panel\Mouse" "MouseThreshold1" $b.Registry.MouseT1 "String"
    Restore-Reg "HKCU:\Control Panel\Mouse" "MouseThreshold2" $b.Registry.MouseT2 "String"

    foreach ($n in $b.NicPower) {
        try {
            Set-NetAdapterPowerManagement -Name $n.Name `
                -SelectiveSuspend $n.SelectiveSuspend `
                -DeviceSleepOnDisconnect $n.DeviceSleepOnDisconnect `
                -D0PacketCoalescing $n.D0PacketCoalescing `
                -NoRestart -ErrorAction SilentlyContinue
        } catch {}
    }

    Write-Host "Backed-up Windows settings restored." -ForegroundColor Green
}
function Uninstall-Governor {
    Require-Admin
    Restore-All
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
    Write-Host "Scheduled task removed. Backup/log folder kept at:" -ForegroundColor Green
    Write-Host $Base
    Read-Host "Press Enter"
}

function Show-Menu {
    Require-Admin
    do {
        Clear-Host
        Write-Host "D7 PERFORMANCE GOVERNOR v1.5" -ForegroundColor Cyan
        Write-Host "Universal game detection + automatic OBS + TikTok performance control" -ForegroundColor Gray
        Write-Host ""
        Write-Host "1) Analyze only"
        Write-Host "2) Install + enable AUTO Governor"
        Write-Host "3) Run Governor in this window"
        Write-Host "4) Restore Windows settings"
        Write-Host "5) Uninstall Governor"
        Write-Host "6) Exit"
        Write-Host ""
        $c = Read-Host "Choose 1-6"
        switch ($c) {
            "1" { Analyze-System }
            "2" { Install-Governor }
            "3" { Run-Governor }
            "4" { Restore-All; Read-Host "Press Enter" }
            "5" { Uninstall-Governor }
            "6" { break }
        }
    } while ($c -ne "6")
}

switch ($Mode) {
    "Install"   { Install-Governor }
    "Run"       { Run-Governor }
    "Analyze"   { Analyze-System }
    "Restore"   { Restore-All }
    "Uninstall" { Uninstall-Governor }
    default     { Show-Menu }
}
