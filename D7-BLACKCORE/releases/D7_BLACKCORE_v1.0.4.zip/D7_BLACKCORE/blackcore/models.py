from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone
import uuid


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class MissionStatus(str, Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    WAITING_APPROVAL = "WAITING_APPROVAL"
    PASSED = "PASSED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class RiskLevel(str, Enum):
    SAFE = "SAFE"
    APPROVAL = "APPROVAL"
    BLOCKED = "BLOCKED"


@dataclass
class Evidence:
    kind: str
    value: str
    detail: str = ""
    created_at: str = field(default_factory=now_iso)


@dataclass
class StepResult:
    ok: bool
    summary: str
    evidence: List[Evidence] = field(default_factory=list)
    data: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None


@dataclass
class MissionStep:
    name: str
    agent: str
    action: str
    args: Dict[str, Any] = field(default_factory=dict)
    risk: RiskLevel = RiskLevel.SAFE
    status: MissionStatus = MissionStatus.PENDING
    result: Optional[StepResult] = None


@dataclass
class Mission:
    goal: str
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: str = field(default_factory=now_iso)
    status: MissionStatus = MissionStatus.PENDING
    mode: str = "ELITE"
    quality_target: float = 95.0
    steps: List[MissionStep] = field(default_factory=list)
    final_score: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
