from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Callable, Any
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import urllib.error
import zipfile

from .config import APP_VERSION, ROOT


@dataclass
class UpdateInfo:
    version: str
    download_url: str
    sha256: str
    notes: str = ""
    channel: str = "alpha"
    minimum_version: str = ""
    published_at: str = ""

    @classmethod
    def from_dict(cls, obj: dict[str, Any]) -> "UpdateInfo":
        required = ["version", "download_url", "sha256"]
        missing = [k for k in required if not str(obj.get(k, "")).strip()]
        if missing:
            raise ValueError("Update manifest missing: " + ", ".join(missing))
        digest = str(obj["sha256"]).strip().lower()
        if not re.fullmatch(r"[a-f0-9]{64}", digest):
            raise ValueError("Manifest sha256 must be a 64-character hex digest")
        url = str(obj["download_url"]).strip()
        if not url.lower().startswith(("https://", "http://")):
            raise ValueError("download_url must be http/https")
        return cls(
            version=str(obj["version"]).strip(),
            download_url=url,
            sha256=digest,
            notes=str(obj.get("notes", "")),
            channel=str(obj.get("channel", "alpha")),
            minimum_version=str(obj.get("minimum_version", "")),
            published_at=str(obj.get("published_at", "")),
        )


def _version_parts(v: str) -> tuple[int, ...]:
    nums = re.findall(r"\d+", v)
    return tuple(int(x) for x in nums[:4]) or (0,)


def is_newer(candidate: str, current: str = APP_VERSION) -> bool:
    a, b = list(_version_parts(candidate)), list(_version_parts(current))
    n = max(len(a), len(b))
    a += [0] * (n - len(a)); b += [0] * (n - len(b))
    return tuple(a) > tuple(b)


class UpdateManager:
    """Evidence-first updater.

    Update contract:
      1. Fetch a small JSON manifest over HTTP(S).
      2. Download the release ZIP.
      3. Verify SHA-256 before extraction.
      4. Stage outside the install directory.
      5. Launch a detached worker which waits for BLACKCORE to exit.
      6. Worker backs up code, applies update, verifies core files, then restarts.
      7. If apply fails the worker restores the backup automatically.

    User data lives in LOCALAPPDATA and is never part of the update payload.
    blackcore.settings.json is preserved during apply.
    """
    def __init__(self, settings):
        self.settings = settings
        self.data_dir = settings.expanded_data_dir()
        self.update_dir = self.data_dir / "updates"
        self.download_dir = self.update_dir / "downloads"
        self.stage_dir = self.update_dir / "stage"
        self.backup_dir = self.update_dir / "backups"
        for p in (self.update_dir, self.download_dir, self.stage_dir, self.backup_dir):
            p.mkdir(parents=True, exist_ok=True)
        self.last_info: UpdateInfo | None = None
        self.last_package: Path | None = None
        self.last_stage: Path | None = None

    def _request(self, url: str, timeout: int | None = None):
        req = urllib.request.Request(url, headers={
            "User-Agent": f"D7-BLACKCORE/{APP_VERSION}",
            "Accept": "application/json, application/zip, application/octet-stream;q=0.9, */*;q=0.5",
            "Cache-Control": "no-cache",
        })
        return urllib.request.urlopen(req, timeout=timeout or int(self.settings.update_timeout_seconds))

    def check(self, manifest_url: str | None = None) -> tuple[bool, str, UpdateInfo | None]:
        url = (manifest_url or self.settings.update_manifest_url or "").strip()
        if not url:
            return False, "No update manifest URL configured.", None
        if not url.lower().startswith(("https://", "http://")):
            return False, "Update URL must start with http:// or https://", None
        try:
            with self._request(url) as r:
                raw = r.read(512 * 1024)
            obj = json.loads(raw.decode("utf-8-sig"))
            if isinstance(obj, dict) and "channels" in obj:
                channel = self.settings.update_channel
                obj = obj["channels"].get(channel) or obj["channels"].get("alpha")
                if not obj:
                    raise ValueError(f"No release in channel {channel}")
            info = UpdateInfo.from_dict(obj)
            self.last_info = info
            if is_newer(info.version, APP_VERSION):
                return True, f"Update {info.version} is available.", info
            return False, f"BLACKCORE is up to date ({APP_VERSION}).", info
        except urllib.error.HTTPError as e:
            return False, f"Update server returned HTTP {e.code}", None
        except urllib.error.URLError as e:
            return False, f"Could not reach update server: {e.reason}", None
        except Exception as e:
            return False, f"Update check failed: {e}", None

    @staticmethod
    def sha256(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    def download(self, info: UpdateInfo, progress: Callable[[int], None] | None = None) -> Path:
        progress = progress or (lambda _: None)
        target = self.download_dir / f"D7_BLACKCORE_{info.version}.zip"
        temp = target.with_suffix(".zip.part")
        try:
            with self._request(info.download_url, timeout=max(30, int(self.settings.update_timeout_seconds))) as r, temp.open("wb") as out:
                total = int(r.headers.get("Content-Length") or 0)
                got = 0
                while True:
                    chunk = r.read(1024 * 512)
                    if not chunk:
                        break
                    out.write(chunk); got += len(chunk)
                    if total > 0:
                        progress(min(90, int((got / total) * 90)))
            actual = self.sha256(temp)
            if actual.lower() != info.sha256.lower():
                raise ValueError(f"SHA-256 mismatch. Expected {info.sha256}, got {actual}")
            temp.replace(target)
            progress(92)
            self.last_package = target
            return target
        finally:
            if temp.exists():
                try: temp.unlink()
                except OSError: pass

    @staticmethod
    def _safe_extract(zip_path: Path, dest: Path):
        dest_resolved = dest.resolve()
        with zipfile.ZipFile(zip_path) as z:
            for member in z.infolist():
                if member.is_dir():
                    continue
                proposed = (dest / member.filename).resolve()
                try:
                    proposed.relative_to(dest_resolved)
                except ValueError:
                    raise ValueError(f"Unsafe path in update package: {member.filename}")
            z.extractall(dest)

    def stage(self, package: Path, info: UpdateInfo) -> Path:
        dest = self.stage_dir / info.version
        if dest.exists(): shutil.rmtree(dest, ignore_errors=True)
        dest.mkdir(parents=True, exist_ok=True)
        self._safe_extract(package, dest)
        candidates = [dest]
        children = [p for p in dest.iterdir() if p.is_dir()]
        if len(children) == 1:
            candidates.insert(0, children[0])
        source = next((p for p in candidates if (p / "main.py").exists() and (p / "blackcore").is_dir()), None)
        if source is None:
            raise ValueError("Update package does not contain a valid D7 BLACKCORE app root")
        required = [source / "main.py", source / "blackcore" / "config.py", source / "ui" / "main_window.py"]
        if not all(p.exists() for p in required):
            raise ValueError("Update package failed core-file verification")
        self.last_stage = source
        return source

    def prepare(self, info: UpdateInfo, progress: Callable[[int], None] | None = None) -> Path:
        package = self.download(info, progress)
        stage = self.stage(package, info)
        if progress: progress(96)
        return stage

    def _worker_script(self) -> Path:
        src = ROOT / "tools" / "update_worker.ps1"
        if not src.exists():
            raise FileNotFoundError("tools/update_worker.ps1 is missing")
        dst = self.update_dir / f"update_worker_{int(time.time())}.ps1"
        shutil.copy2(src, dst)
        return dst

    def apply_after_exit(self, info: UpdateInfo, stage: Path | None = None) -> tuple[bool, str]:
        stage = stage or self.last_stage
        if not stage or not stage.exists():
            return False, "No staged update. Download the update first."
        target = ROOT
        backup = self.backup_dir / f"{APP_VERSION}_before_{info.version}_{int(time.time())}"
        result_file = self.update_dir / "last_update_result.json"
        worker = self._worker_script()
        # Source distribution restarts with the existing venv. Frozen builds restart their exe.
        if getattr(sys, "frozen", False):
            restart_exe = str(Path(sys.executable).resolve())
            restart_args = ""
        else:
            pyw = ROOT / ".venv" / "Scripts" / "pythonw.exe"
            restart_exe = str(pyw if pyw.exists() else Path(sys.executable).resolve())
            restart_args = str(ROOT / "main.py")
        args = [
            "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(worker),
            "-ParentPid", str(os.getpid()),
            "-Source", str(stage),
            "-Target", str(target),
            "-Backup", str(backup),
            "-RestartExe", restart_exe,
            "-RestartArgs", restart_args,
            "-ResultFile", str(result_file),
            "-ExpectedVersion", info.version,
        ]
        try:
            creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
            subprocess.Popen(args, close_fds=True, creationflags=creationflags)
            return True, "Update staged. BLACKCORE will close, apply it, verify it, and restart automatically."
        except Exception as e:
            return False, f"Could not launch update worker: {e}"

    def latest_result(self) -> dict[str, Any] | None:
        p = self.update_dir / "last_update_result.json"
        if not p.exists(): return None
        try: return json.loads(p.read_text(encoding="utf-8-sig"))
        except Exception: return None
