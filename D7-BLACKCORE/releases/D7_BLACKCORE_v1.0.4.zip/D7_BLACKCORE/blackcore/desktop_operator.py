from __future__ import annotations
import time, os
from pathlib import Path
from .models import StepResult, Evidence

class DesktopOperator:
    def __init__(self, data_dir: Path):
        self.data_dir=Path(data_dir); self.shots=self.data_dir/'screenshots'; self.shots.mkdir(parents=True,exist_ok=True)

    def available(self):
        try:
            import pyautogui  # noqa
            return True
        except Exception:
            return False

    def screenshot(self, name: str|None=None) -> StepResult:
        if not self.available(): return StepResult(False,'Desktop control dependency missing',error='PYAUTOGUI_MISSING')
        import pyautogui
        p=self.shots/(name or f'screen_{int(time.time())}.png')
        img=pyautogui.screenshot(); img.save(p)
        return StepResult(True,f'Screenshot captured: {p.name}',[Evidence('screenshot',str(p)),Evidence('size',f'{img.width}x{img.height}')],{'path':str(p),'width':img.width,'height':img.height})

    def click(self,x:int,y:int,button:str='left') -> StepResult:
        if not self.available(): return StepResult(False,'Desktop control dependency missing',error='PYAUTOGUI_MISSING')
        import pyautogui; pyautogui.click(int(x),int(y),button=button)
        return StepResult(True,f'Clicked {x},{y}',[Evidence('desktop_click',f'{x},{y},{button}')])

    def type_text(self,text:str,interval:float=0.01) -> StepResult:
        if not self.available(): return StepResult(False,'Desktop control dependency missing',error='PYAUTOGUI_MISSING')
        import pyautogui; pyautogui.write(text,interval=max(0,min(interval,0.2)))
        return StepResult(True,f'Typed {len(text)} characters',[Evidence('typed_chars',str(len(text)))])

    def hotkey(self,*keys:str) -> StepResult:
        if not self.available(): return StepResult(False,'Desktop control dependency missing',error='PYAUTOGUI_MISSING')
        import pyautogui; pyautogui.hotkey(*keys)
        return StepResult(True,'Hotkey sent: '+'+'.join(keys),[Evidence('hotkey','+'.join(keys))])
