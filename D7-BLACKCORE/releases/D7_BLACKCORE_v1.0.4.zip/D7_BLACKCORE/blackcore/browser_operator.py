from __future__ import annotations
from pathlib import Path
from urllib.parse import quote_plus, urlparse
import time
from .models import StepResult, Evidence

class BrowserOperator:
    """Visible persistent browser with bounded self-healing retries."""
    def __init__(self, profile_dir: str | Path, headless: bool = False, max_retries: int = 2):
        self.profile_dir = str(profile_dir)
        self.headless = headless
        self.max_retries = max(0, min(int(max_retries), 5))
        self._pw = self._ctx = self._page = None

    def start(self) -> StepResult:
        self.close()
        try:
            from playwright.sync_api import sync_playwright
            self._pw = sync_playwright().start()
            self._ctx = self._pw.chromium.launch_persistent_context(
                self.profile_dir, headless=self.headless, viewport={"width": 1440, "height": 900}
            )
            self._page = self._ctx.pages[0] if self._ctx.pages else self._ctx.new_page()
            return StepResult(True, "Browser operator started", [Evidence("profile", self.profile_dir), Evidence("mode", "visible" if not self.headless else "headless")])
        except Exception as e:
            self.close()
            return StepResult(False, "Playwright browser unavailable", error=str(e))

    def ensure(self) -> StepResult | None:
        try:
            if self._page is not None and not self._page.is_closed(): return None
        except Exception:
            pass
        r = self.start()
        return None if r.ok else r

    def _page_snapshot(self,max_chars:int=14000,max_links:int=12) -> dict:
        if self._page is None:
            return {"text":"","links":[]}
        text=""; links=[]
        try:
            text=self._page.locator("body").inner_text(timeout=5000)[:max_chars]
        except Exception:
            pass
        try:
            raw=self._page.eval_on_selector_all("a[href]", "els => els.map(a => ({text:(a.innerText||'').trim(), href:a.href}))")
            seen=set()
            for row in raw or []:
                href=str((row or {}).get('href') or '')
                label=str((row or {}).get('text') or '').strip()
                if not href.startswith(('http://','https://')): continue
                host=(urlparse(href).hostname or '').lower()
                if 'google.' in host or host.endswith('google.com'): continue
                key=href.split('#',1)[0]
                if key in seen: continue
                seen.add(key); links.append({"text":label[:240],"url":key})
                if len(links)>=max_links: break
        except Exception:
            pass
        return {"text":text,"links":links}

    def _navigate(self, url: str, summary: str) -> StepResult:
        last = None
        for attempt in range(self.max_retries + 1):
            err = self.ensure()
            if err: last = err.error or err.summary
            else:
                try:
                    self._page.goto(url, wait_until="domcontentloaded", timeout=30_000)
                    snap=self._page_snapshot()
                    ev=[Evidence("url", self._page.url), Evidence("title", self._page.title()), Evidence("attempt", str(attempt+1))]
                    if snap['links']: ev.append(Evidence('links_found',str(len(snap['links']))))
                    return StepResult(True, summary, ev, snap)
                except Exception as e:
                    last = str(e)
            if attempt < self.max_retries:
                self.close(); time.sleep(min(1.5, 0.35 * (attempt + 1)))
        return StepResult(False, "Browser navigation failed after self-healing retries", error=str(last))

    def search_google(self, query: str) -> StepResult:
        return self._navigate(f"https://www.google.com/search?q={quote_plus(query)}", f"Searched Google: {query}")

    def open(self, url: str) -> StepResult:
        return self._navigate(url, f"Opened {url}")

    def current_page(self) -> StepResult:
        err=self.ensure()
        if err: return err
        try:
            snap=self._page_snapshot()
            return StepResult(True,'Captured current browser page',[Evidence('url',self._page.url),Evidence('title',self._page.title())],snap)
        except Exception as e:
            return StepResult(False,'Could not capture current browser page',error=str(e))

    def close(self):
        try:
            if self._ctx: self._ctx.close()
        except Exception: pass
        try:
            if self._pw: self._pw.stop()
        except Exception: pass
        self._ctx = self._page = self._pw = None
