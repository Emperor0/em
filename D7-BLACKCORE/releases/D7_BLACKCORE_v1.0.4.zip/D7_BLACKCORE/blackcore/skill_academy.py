from __future__ import annotations
import json,re,time
from pathlib import Path
from .models import StepResult,Evidence
class SkillAcademy:
    def __init__(self,skills_dir:Path,llm,memory): self.dir=Path(skills_dir); self.dir.mkdir(parents=True,exist_ok=True); self.llm=llm; self.memory=memory
    def learn(self,name:str,objective:str) -> StepResult:
        safe=re.sub(r'[^a-zA-Z0-9_-]+','_',name).strip('_') or 'skill'
        if not self.llm.available(): return StepResult(False,'AI provider unavailable for Skill Academy',error='LLM_UNAVAILABLE')
        prompt=f'''Create a reusable operational skill for objective: {objective}\nReturn a compact JSON object with keys: name, purpose, prerequisites, steps (array), verification (array), rollback (array), risks (array). No markdown.'''
        raw=self.llm.chat('You are BLACKCORE Skill Academy. Design safe, testable, reusable skills.',prompt)
        try: spec=json.loads(raw[raw.find('{'):raw.rfind('}')+1])
        except Exception: spec={'name':safe,'purpose':objective,'prerequisites':[],'steps':[raw],'verification':['Manual review required'],'rollback':[],'risks':[]}
        spec['name']=safe; spec['version']=1; spec['created_at']=int(time.time())
        p=self.dir/f'{safe}.json'; p.write_text(json.dumps(spec,ensure_ascii=False,indent=2),encoding='utf-8')
        self.memory.remember('skills',safe,spec,0.9)
        return StepResult(True,f'Skill created: {safe}',[Evidence('skill_file',str(p)),Evidence('version','1')],{'skill':spec})
