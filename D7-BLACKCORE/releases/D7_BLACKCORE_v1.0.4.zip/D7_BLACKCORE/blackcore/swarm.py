from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, as_completed
from .models import StepResult,Evidence

class SwarmEngine:
    """Bounded parallel council.

    Every specialist call has a finite timeout. Partial specialist success is
    preserved instead of freezing the mission, and synthesis has its own bound.
    """
    def __init__(self,llm,max_workers:int=4,member_timeout:float=35,synthesis_timeout:float=45):
        self.llm=llm; self.max_workers=max(2,max_workers)
        self.member_timeout=float(member_timeout); self.synthesis_timeout=float(synthesis_timeout)

    def run_council(self,goal:str,roles:list[str]) -> StepResult:
        if not self.llm.available():
            return StepResult(False,'AI provider unavailable for swarm',error='LLM_UNAVAILABLE')

        def one(role):
            system=f'You are the {role} specialist in D7 BLACKCORE. Analyze independently. Be concrete, evidence-aware, and concise.'
            try:
                return role,self.llm.chat(system,goal,timeout=self.member_timeout),None
            except Exception as e:
                return role,"",f'{type(e).__name__}: {e}'

        outputs={}; errors={}
        ex=ThreadPoolExecutor(max_workers=min(self.max_workers,len(roles)))
        try:
            futs=[ex.submit(one,r) for r in roles]
            for f in as_completed(futs):
                role,text,err=f.result()
                if text: outputs[role]=text
                if err: errors[role]=err
        finally:
            ex.shutdown(wait=False,cancel_futures=True)

        if not outputs:
            return StepResult(False,'All specialist calls failed or timed out',
                              [Evidence('specialists_failed',str(len(errors)))],
                              {'errors':errors},error='SWARM_TIMEOUT_OR_FAILURE')

        joined='\n\n'.join(f'[{r}]\n{t}' for r,t in outputs.items())
        try:
            synthesis=self.llm.chat(
                'You are BLACKCORE Master Judge. Synthesize the specialists into one executable answer. Resolve conflicts and list uncertainties.',
                goal+'\n\n'+joined, timeout=self.synthesis_timeout)
            fallback='false'
        except Exception as e:
            # Preserve useful completed work rather than blocking the mission.
            synthesis=joined
            errors['synthesis']=f'{type(e).__name__}: {e}'
            fallback='true'

        ev=[Evidence('specialists_completed',str(len(outputs))),Evidence('synthesis_chars',str(len(synthesis))),Evidence('fallback_synthesis',fallback)]
        if errors: ev.append(Evidence('specialists_failed',str(len(errors))))
        return StepResult(True,f'Swarm completed with {len(outputs)}/{len(roles)} specialists',ev,{'outputs':outputs,'errors':errors,'text':synthesis})
