from __future__ import annotations
import sqlite3, json, shutil, time
from pathlib import Path
from typing import Any, Dict, List, Optional
from .models import now_iso

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS memories (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 namespace TEXT NOT NULL,
 key TEXT NOT NULL,
 value_json TEXT NOT NULL,
 importance REAL NOT NULL DEFAULT 0.5,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL,
 UNIQUE(namespace,key)
);
CREATE TABLE IF NOT EXISTS feedback (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 artifact_type TEXT NOT NULL,
 verdict TEXT NOT NULL,
 notes TEXT NOT NULL,
 score REAL,
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS runs (
 id TEXT PRIMARY KEY,
 goal TEXT NOT NULL,
 status TEXT NOT NULL,
 score REAL,
 payload_json TEXT NOT NULL,
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS skills (
 name TEXT PRIMARY KEY,
 version INTEGER NOT NULL DEFAULT 1,
 spec_json TEXT NOT NULL,
 score REAL NOT NULL DEFAULT 0,
 uses INTEGER NOT NULL DEFAULT 0,
 failures INTEGER NOT NULL DEFAULT 0,
 updated_at TEXT NOT NULL
);
"""

class MemoryStore:
    def __init__(self, db_path: str | Path):
        self.path = Path(db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.recovered_from = None
        try:
            with self._connect() as con:
                con.executescript(SCHEMA)
                result=con.execute("PRAGMA quick_check").fetchone()[0]
                if str(result).lower() != "ok":
                    raise sqlite3.DatabaseError(str(result))
        except sqlite3.DatabaseError:
            if self.path.exists():
                backup=self.path.with_name(f"{self.path.stem}.corrupt.{int(time.time())}{self.path.suffix}")
                shutil.copy2(self.path,backup); self.recovered_from=str(backup); self.path.unlink(missing_ok=True)
                for suffix in ("-wal","-shm"):
                    Path(str(self.path)+suffix).unlink(missing_ok=True)
            with self._connect() as con:
                con.executescript(SCHEMA)

    def _connect(self):
        con = sqlite3.connect(self.path)
        con.row_factory = sqlite3.Row
        return con

    def remember(self, namespace: str, key: str, value: Any, importance: float = 0.5):
        stamp = now_iso()
        with self._connect() as con:
            con.execute("""INSERT INTO memories(namespace,key,value_json,importance,created_at,updated_at)
            VALUES(?,?,?,?,?,?) ON CONFLICT(namespace,key) DO UPDATE SET value_json=excluded.value_json,
            importance=excluded.importance, updated_at=excluded.updated_at""",
            (namespace,key,json.dumps(value,ensure_ascii=False),importance,stamp,stamp))

    def recall(self, namespace: str, key: str, default=None):
        with self._connect() as con:
            row = con.execute("SELECT value_json FROM memories WHERE namespace=? AND key=?",(namespace,key)).fetchone()
        return default if not row else json.loads(row["value_json"])

    def search(self, text: str, limit: int = 20) -> List[Dict[str,Any]]:
        q = f"%{text}%"
        with self._connect() as con:
            rows = con.execute("SELECT * FROM memories WHERE key LIKE ? OR value_json LIKE ? ORDER BY importance DESC, updated_at DESC LIMIT ?",(q,q,limit)).fetchall()
        return [dict(r) for r in rows]

    def add_feedback(self, artifact_type: str, verdict: str, notes: str, score: float | None = None):
        with self._connect() as con:
            con.execute("INSERT INTO feedback(artifact_type,verdict,notes,score,created_at) VALUES(?,?,?,?,?)",
                        (artifact_type,verdict,notes,score,now_iso()))

    def save_run(self, mission):
        stamp = now_iso()
        payload = json.dumps(mission.to_dict(), ensure_ascii=False, default=str)
        with self._connect() as con:
            con.execute("""INSERT INTO runs(id,goal,status,score,payload_json,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET status=excluded.status,score=excluded.score,
            payload_json=excluded.payload_json,updated_at=excluded.updated_at""",
            (mission.id,mission.goal,str(mission.status.value),mission.final_score,payload,mission.created_at,stamp))
