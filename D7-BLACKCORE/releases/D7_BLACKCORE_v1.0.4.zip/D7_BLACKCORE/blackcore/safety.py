from __future__ import annotations
from .models import RiskLevel

BLOCKED_TOKENS = [
    "disable defender", "turn off defender", "disable firewall", "bypass anti-cheat",
    "steal password", "dump credentials", "keylogger", "ransomware", "delete system32"
]
APPROVAL_TOKENS = [
    "send email", "send message", "publish", "upload", "post", "delete", "remove file",
    "purchase", "buy", "pay", "transfer", "sign contract", "submit application"
]

class SafetyPolicy:
    def classify(self, action: str, args: dict | None = None) -> RiskLevel:
        text = (action + " " + str(args or {})).lower()
        if any(t in text for t in BLOCKED_TOKENS):
            return RiskLevel.BLOCKED
        if any(t in text for t in APPROVAL_TOKENS):
            return RiskLevel.APPROVAL
        return RiskLevel.SAFE
