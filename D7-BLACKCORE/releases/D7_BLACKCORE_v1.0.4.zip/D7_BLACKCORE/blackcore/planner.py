from __future__ import annotations
import re
from .models import Mission, MissionStep

class Planner:
    """Deterministic fast paths first, AI councils only when reasoning is actually needed."""

    def plan(self, goal: str, mode: str='ELITE', quality_target: float=95.0) -> Mission:
        g=goal.strip(); gl=g.lower(); m=Mission(goal=g,mode=mode,quality_target=quality_target)

        # Research -> verify -> desktop report -> read-back is a common compound mission.
        # Keep it off the heavyweight multi-agent council path.
        report_file=self._extract_filename(g)
        research_query=self._extract_research_query(g)
        if report_file and research_query and self._looks_like_research_report(g):
            report_path=r"%USERPROFILE%\Desktop"+"\\"+report_file
            m.steps=[
                MissionStep('البحث في الويب','مشغّل المتصفح','search_web',{'query':research_query}),
                MissionStep('فتح المصدر وتحليل الأدلة','محلل الأبحاث','research_analysis',{'query':research_query}),
                MissionStep('حفظ تقرير البحث','مشغّل النظام','write_context_text',{'path':report_path}),
                MissionStep('قراءة التقرير والتحقق','مشغّل النظام','system:read_text',{'path':report_path}),
                MissionStep('تدقيق مستقل','مراقب الجودة','quality_review',{}),
            ]
            return m

        folder = self._extract_folder(g)
        filename = self._extract_filename(g)
        content = self._extract_content(g)
        if folder and filename and content is not None and self._looks_like_local_file_task(g):
            base = r"%USERPROFILE%\Desktop"
            folder_path = base + "\\" + folder
            file_path = folder_path + "\\" + filename
            m.steps=[
                MissionStep('إنشاء المجلد','مشغّل النظام','system:create_folder',{'path':folder_path}),
                MissionStep('كتابة الملف','مشغّل النظام','system:write_text',{'path':file_path,'text':content}),
                MissionStep('التحقق من المحتوى','مشغّل النظام','system:read_text',{'path':file_path}),
                MissionStep('تدقيق التنفيذ','مراقب الجودة','quality_review',{}),
            ]
            return m

        qmatch=re.search(r'(?:ابحث|دور)(?:\s+لي)?(?:\s+في\s+الإنترنت)?(?:\s+عن)?\s+(.+)',g,re.I)
        if qmatch:
            q=qmatch.group(1).strip(); m.steps=[MissionStep('البحث في الويب','مشغّل المتصفح','search_web',{'query':q}),MissionStep('تحليل البحث','قسم الأبحاث','department',{'department':'research','goal':q}),MissionStep('تدقيق مستقل','مراقب الجودة','quality_review',{})]; return m
        if gl.startswith('http://') or gl.startswith('https://'):
            m.steps=[MissionStep('فتح الرابط','مشغّل المتصفح','open_url',{'url':g})]; return m
        if any(x in gl for x in ['screenshot','لقطة شاشة','صور الشاشة']):
            m.steps=[MissionStep('التقاط الشاشة','مشغّل الكمبيوتر','desktop:screenshot',{})]; return m
        if 'يوتيوب' in g or 'youtube' in gl:
            m.steps=[MissionStep('استراتيجية القناة','قسم يوتيوب','department',{'department':'youtube','goal':g}),MissionStep('جمع الأدلة','قسم الأبحاث','research',{'topic':g}),MissionStep('المراجعة النهائية','مراقب الجودة','quality_review',{})]; return m
        if any(x in g for x in ['ربح','دخل','فلوس']) or any(x in gl for x in ['profit','money','revenue']):
            m.steps=[MissionStep('تحليل الفرصة','قسم الإيرادات','department',{'department':'revenue','goal':g}),MissionStep('أدلة السوق','قسم الأبحاث','research',{'topic':g}),MissionStep('مراجعة المخاطر والجودة','مراقب الجودة','quality_review',{})]; return m
        if any(x in g for x in ['تطبيق','برنامج','برمجة']) or any(x in gl for x in ['app','build','code','developer']):
            m.steps=[MissionStep('المجلس الهندسي','قسم البرمجة','department',{'department':'developer','goal':g}),MissionStep('مراجعة التنفيذ','مراقب الجودة','quality_review',{})]; return m
        if any(x in g for x in ['تعلم مهارة','تعلم','مهارة']) or 'learn skill' in gl:
            m.steps=[MissionStep('بناء مهارة قابلة لإعادة الاستخدام','أكاديمية المهارات','learn_skill',{'name':'mission_skill','objective':g}),MissionStep('فحص المهارة','مراقب الجودة','quality_review',{})]; return m
        m.steps=[MissionStep('مجلس متخصص متوازٍ','BLACKCORE Swarm','department',{'department':'general','goal':g}),MissionStep('المراجعة النهائية','مراقب الجودة','quality_review',{})]
        return m

    @staticmethod
    def _looks_like_research_report(g:str)->bool:
        gl=g.lower()
        has_search=any(x in g for x in ['ابحث','دور']) or 'search' in gl
        has_report=('.txt' in gl or '.md' in gl) and (('سطح المكتب' in g) or ('desktop' in gl))
        has_verify=any(x in g for x in ['تحقق','المصدر','تاريخ التحقق']) or any(x in gl for x in ['verify','source'])
        return has_search and has_report and has_verify

    @staticmethod
    def _extract_research_query(g:str):
        patterns=[
            r'(?:ابحث|دور)(?:\s+لي)?(?:\s+في\s+الإنترنت)?(?:\s+عن)?\s+(.+?)(?=،|,|\s+تحقق\b|\s+ثم\b|\s+بعد\s+ذلك\b|$)',
            r'(?:search)(?:\s+the\s+web|\s+online)?(?:\s+for)?\s+(.+?)(?=,|\s+verify\b|\s+then\b|$)',
        ]
        for p in patterns:
            m=re.search(p,g,re.I)
            if m:
                q=m.group(1).strip(' .،,')
                if q:return q
        return None

    @staticmethod
    def _looks_like_local_file_task(g: str) -> bool:
        gl=g.lower()
        return any(x in g for x in ['مجلد','ملف','سطح المكتب','اكتب فيه','أنشئ','انشئ']) or any(x in gl for x in ['folder','file','desktop','write'])

    @staticmethod
    def _extract_folder(g: str):
        patterns=[
            r'(?:مجلد|folder)\s+(?:على\s+سطح\s+المكتب\s+)?(?:باسم|named)\s*[`"“”\']?([\w .-]+?)[`"“”\']?(?:،|,|\s+و(?:داخله|داخله)|\s+and\s+inside|$)',
            r'(?:باسم|named)\s*[`"“”\']?([A-Za-z0-9_. -]{2,80})[`"“”\']?\s*(?:،|,)?\s*(?:و?داخله|with)',
        ]
        for p in patterns:
            m=re.search(p,g,re.I)
            if m:
                v=m.group(1).strip(' .،,')
                if v: return v
        return None

    @staticmethod
    def _extract_filename(g: str):
        m=re.search(r'(?:ملف|file)\s+(?:باسم|named)?\s*[`"“”\']?([\w .-]+\.[A-Za-z0-9]{1,8})[`"“”\']?',g,re.I)
        if m:return m.group(1).strip()
        m=re.search(r'\b([A-Za-z0-9_. -]+\.(?:txt|md|json|csv))\b',g,re.I)
        return m.group(1).strip() if m else None

    @staticmethod
    def _extract_content(g: str):
        patterns=[
            r'(?:واكتب\s+فيه|اكتب\s+فيه|write\s+(?:in\s+it|into\s+it))\s*[:：]?\s*[`"“”\']?(.+?)[`"“”\']?(?:[.。]\s*(?:بعد|then)|،\s*(?:بعد|ثم)|\s+(?:بعد\s+ذلك|ثم|then)\b|$)',
        ]
        for p in patterns:
            m=re.search(p,g,re.I)
            if m:
                return m.group(1).strip(' `"“”\'،,.')
        return None
