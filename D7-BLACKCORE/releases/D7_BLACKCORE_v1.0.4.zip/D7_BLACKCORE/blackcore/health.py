from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import importlib.util
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import time

from .config import ROOT, APP_VERSION


@dataclass
class HealthCheck:
    name: str
    ok: bool
    detail: str
    repairable: bool = False
    severity: str = "info"

    def to_dict(self): return asdict(self)


class HealthManager:
    REQUIRED = [
        "main.py", "blackcore/config.py", "blackcore/orchestrator.py", "blackcore/memory.py",
        "blackcore/updater.py", "blackcore/desktop_operator.py", "blackcore/swarm.py", "blackcore/skill_academy.py",
        "blackcore/departments.py", "blackcore/audit.py", "blackcore/recovery.py", "ui/main_window.py", "requirements.txt"
    ]

    def __init__(self, core):
        self.core = core
        self.settings = core.settings
        self.data = self.settings.expanded_data_dir()

    def scan(self) -> list[HealthCheck]:
        checks: list[HealthCheck] = []
        missing = [p for p in self.REQUIRED if not (ROOT / p).exists()]
        checks.append(HealthCheck("Core files", not missing, "OK" if not missing else "Missing: " + ", ".join(missing), bool(missing), "critical" if missing else "info"))

        try:
            self.settings.ensure_dirs()
            probe = self.data / "logs" / ".write_test"
            probe.write_text("ok", encoding="utf-8"); probe.unlink(missing_ok=True)
            checks.append(HealthCheck("Data directory", True, str(self.data)))
        except Exception as e:
            checks.append(HealthCheck("Data directory", False, str(e), True, "critical"))

        db = self.data / "memory" / "blackcore.db"
        try:
            with sqlite3.connect(db) as con:
                result = con.execute("PRAGMA quick_check").fetchone()[0]
            ok = str(result).lower() == "ok"
            checks.append(HealthCheck("Memory database", ok, str(result), not ok, "critical" if not ok else "info"))
        except Exception as e:
            checks.append(HealthCheck("Memory database", False, str(e), True, "critical"))

        try:
            free = shutil.disk_usage(self.data).free / (1024**3)
            checks.append(HealthCheck("Free disk", free >= 2.0, f"{free:.1f} GB free", False, "warning" if free < 2 else "info"))
        except Exception as e:
            checks.append(HealthCheck("Free disk", False, str(e), False, "warning"))

        for module in ("PySide6", "psutil", "playwright", "pyautogui", "PIL"):
            ok = importlib.util.find_spec(module) is not None
            checks.append(HealthCheck(f"Dependency: {module}", ok, "Installed" if ok else "Missing", not ok, "critical" if not ok else "info"))

        checks.append(HealthCheck("AI provider", self.core.llm.available(force=True), self.settings.llm_base_url, False, "warning"))

        gov = self.core.governor.status()
        checks.append(HealthCheck("D7 Governor", gov.ok, gov.summary, False, "info"))

        crash = self.data / "logs" / "crash.log"
        if crash.exists() and crash.stat().st_size:
            age = max(0, time.time() - crash.stat().st_mtime)
            recent = age < 7 * 86400
            checks.append(HealthCheck("Recent crash log", not recent, "Crash log detected" if recent else "No recent crashes", True if recent else False, "warning" if recent else "info"))
        else:
            checks.append(HealthCheck("Recent crash log", True, "No crash log"))
        return checks

    def repair(self) -> dict[str, Any]:
        actions: list[str] = []
        errors: list[str] = []
        self.settings.ensure_dirs()

        # Browser stale locks are safe to remove only after the controlled BLACKCORE browser has closed.
        try:
            self.core.browser.close()
            profile = self.data / "browser_profile"
            for name in ("SingletonLock", "SingletonCookie", "SingletonSocket"):
                p = profile / name
                if p.exists() or p.is_symlink():
                    try: p.unlink(); actions.append(f"Removed stale browser lock: {name}")
                    except OSError: pass
        except Exception as e:
            errors.append(f"Browser cleanup: {e}")

        # Integrity-protect memory: never delete a corrupt DB without preserving it.
        db = self.data / "memory" / "blackcore.db"
        try:
            with sqlite3.connect(db) as con:
                ok = str(con.execute("PRAGMA quick_check").fetchone()[0]).lower() == "ok"
            if not ok:
                backup = db.with_name(f"blackcore.corrupt.{int(time.time())}.db")
                shutil.copy2(db, backup)
                db.unlink()
                from .memory import MemoryStore
                self.core.memory = MemoryStore(db)
                actions.append(f"Corrupt memory DB preserved as {backup.name}; fresh DB created")
        except Exception as e:
            errors.append(f"Memory repair: {e}")

        # Source installs can repair Python dependencies in-place. Frozen EXE builds do not need pip.
        if not getattr(sys, "frozen", False):
            try:
                req = ROOT / "requirements.txt"
                subprocess.run([sys.executable, "-m", "pip", "install", "-r", str(req)], check=True, timeout=600,
                               stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
                actions.append("Python dependencies verified/repaired")
            except Exception as e:
                errors.append(f"Dependency repair: {e}")
            try:
                subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=True, timeout=900,
                               stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
                actions.append("Playwright Chromium verified/repaired")
            except Exception as e:
                errors.append(f"Browser engine repair: {e}")

        # Archive crash log after a repair attempt; history is preserved.
        crash = self.data / "logs" / "crash.log"
        if crash.exists() and crash.stat().st_size:
            archive = self.data / "logs" / f"crash.repaired.{int(time.time())}.log"
            try:
                shutil.copy2(crash, archive); crash.write_text("", encoding="utf-8")
                actions.append(f"Crash log archived: {archive.name}")
            except Exception as e:
                errors.append(f"Crash-log archive: {e}")
        return {"ok": not errors, "actions": actions, "errors": errors, "version": APP_VERSION}
