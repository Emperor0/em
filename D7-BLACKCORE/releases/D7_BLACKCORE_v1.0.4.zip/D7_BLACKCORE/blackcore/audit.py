from __future__ import annotations
import json, threading
from pathlib import Path
from .models import now_iso
class AuditLog:
    def __init__(self,path:Path): self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True); self._lock=threading.Lock()
    def write(self,event:str,**payload):
        row={'at':now_iso(),'event':event,**payload}
        with self._lock:
            with self.path.open('a',encoding='utf-8') as f: f.write(json.dumps(row,ensure_ascii=False,default=str)+'\n')
        return row
    def tail(self,n:int=100):
        if not self.path.exists(): return []
        lines=self.path.read_text(encoding='utf-8',errors='replace').splitlines()[-n:]
        out=[]
        for x in lines:
            try: out.append(json.loads(x))
            except Exception: pass
        return out
