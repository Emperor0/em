from __future__ import annotations
import json
from pathlib import Path
from typing import Dict, Any

DEFAULT_SKILLS = {
  "browser_research": {"version":1,"agents":["Researcher","FactChecker"],"quality_gate":95,"description":"Visible browser research with source evidence."},
  "windows_operator": {"version":1,"agents":["Operator","QA"],"quality_gate":95,"description":"Operate Windows files/apps with evidence and approvals."},
  "youtube_longform": {"version":1,"agents":["Researcher","Strategist","Writer","Editor","Audio","QA","Publisher"],"quality_gate":95,"description":"Long-form YouTube production workflow; publishing requires approval."},
  "software_builder": {"version":1,"agents":["Architect","Developer","Tester","Security","QA"],"quality_gate":95,"description":"Build-test-repair software workflow."}
}

class SkillRegistry:
    def __init__(self, directory: str | Path):
        self.dir=Path(directory); self.dir.mkdir(parents=True, exist_ok=True)
        self.bootstrap()
    def bootstrap(self):
        for name,spec in DEFAULT_SKILLS.items():
            p=self.dir/f"{name}.json"
            if not p.exists(): p.write_text(json.dumps({"name":name,**spec},ensure_ascii=False,indent=2),encoding="utf-8")
    def all(self) -> Dict[str,Any]:
        out={}
        for p in self.dir.glob("*.json"):
            try:
                obj=json.loads(p.read_text(encoding="utf-8")); out[obj["name"]]=obj
            except Exception: pass
        return out
