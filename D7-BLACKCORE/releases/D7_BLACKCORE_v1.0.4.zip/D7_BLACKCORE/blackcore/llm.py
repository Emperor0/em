from __future__ import annotations
import json
import os
import subprocess
import time
import urllib.request
from pathlib import Path
from threading import Lock


class LLMProvider:
    """AI adapter with native OpenCode support plus OpenAI-compatible fallback.

    v1.0.4 adds bounded inference timeouts and an OpenCode abort hook so one
    slow model request cannot freeze an entire BLACKCORE mission indefinitely.
    """

    def __init__(self, base_url: str, api_key: str = "", model: str = "", provider_type: str = "auto",
                 auto_start: bool = True, opencode_executable: str = ""):
        raw = (base_url or "http://127.0.0.1:8082").rstrip("/")
        self.base_url = raw
        self.origin_url = raw[:-3] if raw.endswith("/v1") else raw
        self.api_key = api_key
        self.model = model
        self.provider_type = (provider_type or "auto").lower()
        self.auto_start = bool(auto_start)
        self.opencode_executable = opencode_executable or ""
        self._last_available = False
        self._last_check = 0.0
        self._detected_type = "unknown"
        self._server_process = None
        self._server_version = ""
        self._last_error = ""
        self._active_session_id: str | None = None
        self._session_lock = Lock()

    @property
    def detected_type(self) -> str:
        return self._detected_type

    @property
    def server_version(self) -> str:
        return self._server_version

    @property
    def last_error(self) -> str:
        return self._last_error

    def _headers(self, json_body: bool = False):
        h = {}
        if json_body:
            h["Content-Type"] = "application/json"
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    def _json_request(self, url: str, method: str = "GET", payload=None, timeout: float = 5):
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=self._headers(payload is not None), method=method)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read().decode("utf-8")
            return json.loads(body) if body else None

    def _check_opencode(self) -> bool:
        try:
            obj = self._json_request(self.origin_url + "/global/health", timeout=2)
            ok = bool(isinstance(obj, dict) and obj.get("healthy") is True)
            if ok:
                self._detected_type = "opencode"
                self._server_version = str(obj.get("version", ""))
                self._last_error = ""
            return ok
        except Exception as e:
            self._last_error = str(e)
            return False

    def _check_openai(self) -> bool:
        base = self.base_url if self.base_url.endswith("/v1") else self.base_url + "/v1"
        try:
            obj = self._json_request(base + "/models", timeout=2)
            if isinstance(obj, dict):
                self._detected_type = "openai"
                self._last_error = ""
                return True
        except Exception as e:
            self._last_error = str(e)
        return False

    @staticmethod
    def _candidate_opencode_paths() -> list[Path]:
        home = Path.home()
        local = os.environ.get("LOCALAPPDATA", "")
        candidates = [
            home / ".opencode" / "bin" / "opencode.exe",
            home / ".local" / "bin" / "opencode.exe",
            home / ".local" / "bin" / "tcc-opencode.exe",
        ]
        if local:
            candidates += [Path(local) / "Programs" / "opencode" / "opencode.exe"]
        return candidates

    def find_opencode(self) -> str | None:
        if self.opencode_executable:
            p = Path(os.path.expandvars(self.opencode_executable)).expanduser()
            if p.exists():
                return str(p)
        for p in self._candidate_opencode_paths():
            if p.exists():
                return str(p)
        import shutil
        return shutil.which("opencode") or shutil.which("tcc-opencode")

    def start_opencode(self) -> bool:
        if os.name != "nt":
            self._last_error = "OpenCode auto-start is Windows-only in this build"
            return False
        exe = self.find_opencode()
        if not exe:
            self._last_error = "OpenCode executable not found"
            return False
        try:
            from urllib.parse import urlparse
            parsed = urlparse(self.origin_url)
            host = parsed.hostname or "127.0.0.1"
            port = parsed.port or 8082
            flags = 0
            if hasattr(subprocess, "CREATE_NO_WINDOW"): flags |= subprocess.CREATE_NO_WINDOW
            if hasattr(subprocess, "DETACHED_PROCESS"): flags |= subprocess.DETACHED_PROCESS
            self._server_process = subprocess.Popen(
                [exe, "serve", "--hostname", host, "--port", str(port)],
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                close_fds=True, creationflags=flags,
            )
            for _ in range(30):
                time.sleep(0.2)
                if self._check_opencode():
                    return True
            self._last_error = "OpenCode process started but health endpoint did not become ready"
        except Exception as e:
            self._last_error = f"OpenCode auto-start failed: {e}"
        return False

    def available(self, force: bool = False) -> bool:
        now = time.monotonic()
        if not force and self._last_check and (now - self._last_check) < 10:
            return self._last_available
        wanted = self.provider_type
        ok = False
        if wanted in ("auto", "opencode"):
            ok = self._check_opencode()
            if not ok and self.auto_start:
                ok = self.start_opencode()
        if not ok and wanted in ("auto", "openai"):
            ok = self._check_openai()
        self._last_available = ok
        self._last_check = time.monotonic()
        return ok

    def cached_available(self) -> bool:
        return bool(self._last_available)

    def provider_info(self):
        if not self.available(force=True):
            return {"type": self._detected_type, "connected": [], "error": self._last_error}
        if self._detected_type == "opencode":
            try:
                obj = self._json_request(self.origin_url + "/provider", timeout=8)
                return {"type": "opencode", "version": self._server_version, **(obj if isinstance(obj, dict) else {"raw": obj})}
            except Exception as e:
                return {"type": "opencode", "version": self._server_version, "error": str(e)}
        return {"type": "openai", "models": self.models()}

    def models(self):
        if self._detected_type == "opencode" or self._check_opencode():
            return self._json_request(self.origin_url + "/provider", timeout=8)
        base = self.base_url if self.base_url.endswith("/v1") else self.base_url + "/v1"
        return self._json_request(base + "/models", timeout=8)

    @staticmethod
    def _extract_opencode_text(obj) -> str:
        if not isinstance(obj, dict):
            return str(obj)
        texts = []
        for part in obj.get("parts", []) or []:
            if isinstance(part, dict) and part.get("type") == "text" and part.get("text"):
                texts.append(str(part["text"]))
        if texts:
            return "\n".join(texts).strip()
        if isinstance(obj.get("text"), str):
            return obj["text"]
        return json.dumps(obj, ensure_ascii=False)

    def _set_active_session(self, session_id: str | None):
        with self._session_lock:
            self._active_session_id = session_id

    def abort_active(self) -> bool:
        """Best-effort abort for a currently running OpenCode prompt."""
        with self._session_lock:
            session_id = self._active_session_id
        if not session_id or self._detected_type != "opencode":
            return False
        try:
            self._json_request(self.origin_url + f"/session/{session_id}/abort", "POST", {}, timeout=3)
            return True
        except Exception:
            return False

    def _chat_opencode(self, system: str, user: str, model: str | None = None, timeout: float = 60) -> str:
        session = self._json_request(self.origin_url + "/session", "POST", {"title": "D7 BLACKCORE"}, timeout=min(10, timeout))
        if not isinstance(session, dict) or not session.get("id"):
            raise RuntimeError("OpenCode did not return a session id")
        session_id = str(session["id"])
        self._set_active_session(session_id)
        try:
            payload = {"system": system, "parts": [{"type": "text", "text": user}]}
            mdl = model or self.model
            if mdl and "/" in mdl:
                provider_id, model_id = mdl.split("/", 1)
                payload["model"] = {"providerID": provider_id,"modelID": model_id}
            obj = self._json_request(self.origin_url + f"/session/{session_id}/message", "POST", payload, timeout=timeout)
            text = self._extract_opencode_text(obj)
            if not text:
                raise RuntimeError("OpenCode returned no text response")
            return text
        finally:
            self._set_active_session(None)

    def _chat_openai(self, system: str, user: str, model: str | None = None, temperature: float = 0.2, timeout: float = 60) -> str:
        mdl = model or self.model
        if not mdl:
            data = self.models().get("data", [])
            if not data:
                raise RuntimeError("No model configured or discovered")
            mdl = data[0].get("id")
        base = self.base_url if self.base_url.endswith("/v1") else self.base_url + "/v1"
        obj = self._json_request(base + "/chat/completions", "POST", {
            "model": mdl,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "temperature": temperature,
        }, timeout=timeout)
        return obj["choices"][0]["message"]["content"]

    def chat(self, system: str, user: str, model: str | None = None, temperature: float = 0.2, timeout: float = 60) -> str:
        if not self.available():
            raise RuntimeError(self._last_error or "AI provider unavailable")
        if self._detected_type == "opencode":
            return self._chat_opencode(system, user, model, timeout=timeout)
        return self._chat_openai(system, user, model, temperature, timeout=timeout)
