from __future__ import annotations
from .models import StepResult,Evidence
class DepartmentHub:
    ROLES={
      'research':['Researcher','Fact Checker','Analyst'],
      'developer':['Architect','Developer','Tester','Security Reviewer'],
      'youtube':['Channel Strategist','Story Editor','Retention Critic','SEO Analyst','Copyright Reviewer'],
      'revenue':['Market Researcher','Offer Designer','Sales Strategist','Risk Analyst'],
      'design':['Creative Director','UX Critic','Accessibility Reviewer'],
      'general':['Planner','Operator','Auditor']}
    def __init__(self,swarm): self.swarm=swarm
    def run(self,department:str,goal:str)->StepResult:
        roles=self.ROLES.get(department,self.ROLES['general'])
        r=self.swarm.run_council(goal,roles)
        if r.ok: r.evidence.append(Evidence('department',department))
        return r
