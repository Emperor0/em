from __future__ import annotations
import os, shutil, subprocess, webbrowser, json
from pathlib import Path
from typing import Any
from .models import StepResult, Evidence

class SystemOperator:
    def __init__(self, workspace: str | Path):
        self.workspace = Path(workspace)
        self.workspace.mkdir(parents=True, exist_ok=True)

    def execute(self, action: str, **args) -> StepResult:
        fn = getattr(self, f"act_{action}", None)
        if not fn:
            return StepResult(False, f"Unknown system action: {action}", error="UNKNOWN_ACTION")
        try:
            return fn(**args)
        except Exception as e:
            return StepResult(False, f"{action} failed", error=f"{type(e).__name__}: {e}")

    def act_open_url(self, url: str) -> StepResult:
        ok = webbrowser.open(url, new=2)
        return StepResult(bool(ok), f"Opened {url}", [Evidence("url", url, "Opened in default browser")])

    def act_search_web(self, query: str) -> StepResult:
        from urllib.parse import quote_plus
        url = f"https://www.google.com/search?q={quote_plus(query)}"
        return self.act_open_url(url)

    def act_open_path(self, path: str) -> StepResult:
        p = Path(os.path.expandvars(path)).expanduser().resolve()
        if not p.exists():
            return StepResult(False, f"Path does not exist: {p}", error="NOT_FOUND")
        if os.name == "nt": os.startfile(str(p))  # type: ignore[attr-defined]
        elif shutil.which("xdg-open"): subprocess.Popen(["xdg-open", str(p)])
        else: return StepResult(False, "No OS opener available", error="NO_OPENER")
        return StepResult(True, f"Opened {p}", [Evidence("path", str(p), "Verified before opening")])

    def act_list_files(self, path: str, limit: int = 200) -> StepResult:
        p = Path(os.path.expandvars(path)).expanduser().resolve()
        if not p.exists() or not p.is_dir():
            return StepResult(False, f"Directory not found: {p}", error="NOT_FOUND")
        items = []
        for i, x in enumerate(sorted(p.iterdir(), key=lambda z: (not z.is_dir(), z.name.lower()))):
            if i >= limit: break
            try:
                items.append({"name":x.name,"path":str(x),"type":"dir" if x.is_dir() else "file","size":0 if x.is_dir() else x.stat().st_size})
            except OSError:
                pass
        return StepResult(True, f"Found {len(items)} items in {p}", [Evidence("path", str(p)), Evidence("count", str(len(items)))], {"items":items})

    def act_create_folder(self, path: str) -> StepResult:
        p = Path(os.path.expandvars(path)).expanduser().resolve()
        p.mkdir(parents=True, exist_ok=True)
        return StepResult(p.exists(), f"Folder ready: {p}", [Evidence("path", str(p)), Evidence("exists", str(p.exists()))])

    def act_read_text(self, path: str, max_chars: int = 200_000) -> StepResult:
        p = Path(os.path.expandvars(path)).expanduser().resolve()
        if not p.is_file(): return StepResult(False, f"File not found: {p}", error="NOT_FOUND")
        text = p.read_text(encoding="utf-8", errors="replace")[:max_chars]
        return StepResult(True, f"Read {p.name}", [Evidence("path", str(p)), Evidence("chars", str(len(text)))], {"text": text})

    def act_write_text(self, path: str, text: str) -> StepResult:
        p = Path(os.path.expandvars(path)).expanduser().resolve()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
        verify = p.read_text(encoding="utf-8")
        return StepResult(verify == text, f"Wrote {p}", [Evidence("path", str(p)), Evidence("bytes", str(p.stat().st_size))])

    def act_copy_file(self, src: str, dst: str) -> StepResult:
        s, d = Path(src).expanduser().resolve(), Path(dst).expanduser().resolve()
        d.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(s,d)
        return StepResult(d.exists() and d.stat().st_size == s.stat().st_size, f"Copied to {d}", [Evidence("source", str(s)), Evidence("destination", str(d)), Evidence("bytes", str(d.stat().st_size))])

    def act_launch_app(self, command: str) -> StepResult:
        if os.name == "nt":
            p = subprocess.Popen(command, shell=True)
        else:
            p = subprocess.Popen(command.split())
        return StepResult(True, f"Launched: {command}", [Evidence("pid", str(p.pid)), Evidence("command", command)])

    def system_snapshot(self) -> dict[str, Any]:
        out = {"platform": os.name, "cwd": os.getcwd()}
        try:
            import psutil
            out.update({
                "cpu_percent": psutil.cpu_percent(interval=0.1),
                "ram_percent": psutil.virtual_memory().percent,
                "processes": len(psutil.pids()),
            })
        except Exception:
            pass
        return out
