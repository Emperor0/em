from __future__ import annotations
import json, os
from pathlib import Path
from .models import StepResult, Evidence

class D7GovernorAdapter:
    def __init__(self):
        base = Path(os.environ.get("ProgramData", r"C:\ProgramData")) / "D7PerformanceGovernor"
        self.base = base
        self.status_file = base / "status.json"
        self.config_file = base / "config.json"
        self.games_file = base / "games.json"

    def status(self) -> StepResult:
        if not self.status_file.exists():
            return StepResult(False, "D7 Performance Governor is not currently installed/running", error="NOT_INSTALLED")
        try:
            data=json.loads(self.status_file.read_text(encoding="utf-8-sig"))
            return StepResult(True, f"Governor state: {data.get('state','UNKNOWN')}", [Evidence("path",str(self.status_file)),Evidence("state",str(data.get('state','UNKNOWN')))], data)
        except Exception as e:
            return StepResult(False, "Could not read Governor status", error=str(e))
