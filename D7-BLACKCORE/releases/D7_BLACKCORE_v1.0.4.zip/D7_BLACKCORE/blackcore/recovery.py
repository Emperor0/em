from __future__ import annotations
import json,shutil,time
from pathlib import Path
from .models import StepResult,Evidence
class RecoveryManager:
    def __init__(self,data:Path): self.root=Path(data)/'checkpoints'; self.root.mkdir(parents=True,exist_ok=True)
    def checkpoint_file(self,path:str) -> StepResult:
        p=Path(path).expanduser().resolve()
        if not p.is_file(): return StepResult(False,f'File not found: {p}',error='NOT_FOUND')
        stamp=str(int(time.time())); d=self.root/stamp; d.mkdir(parents=True,exist_ok=True); dst=d/p.name; shutil.copy2(p,dst)
        meta={'original':str(p),'backup':str(dst),'created_at':stamp}; (d/'checkpoint.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
        return StepResult(True,'Checkpoint created',[Evidence('checkpoint',str(d)),Evidence('source',str(p))],meta)
    def restore(self,checkpoint_dir:str) -> StepResult:
        d=Path(checkpoint_dir); meta=json.loads((d/'checkpoint.json').read_text(encoding='utf-8')); src=Path(meta['backup']); dst=Path(meta['original']); shutil.copy2(src,dst)
        return StepResult(True,'Checkpoint restored',[Evidence('restored',str(dst)),Evidence('backup',str(src))])
