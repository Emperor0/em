from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List
from .models import StepResult

@dataclass
class QualityReport:
    score: float
    passed: bool
    dimensions: Dict[str, float] = field(default_factory=dict)
    issues: List[str] = field(default_factory=list)

class QualityEngine:
    """Evidence-first quality gate. Scores are deterministic for operational tasks."""
    def __init__(self, target: float = 95.0):
        self.target = target

    def evaluate_step(self, result: StepResult) -> QualityReport:
        if not result.ok:
            return QualityReport(0.0, False, {"execution": 0.0}, [result.error or result.summary])
        evidence_score = min(100.0, 50.0 + 25.0 * len(result.evidence))
        execution_score = 100.0
        error_score = 100.0 if not result.error else 0.0
        score = round(0.50*execution_score + 0.35*evidence_score + 0.15*error_score, 2)
        issues = [] if score >= self.target else ["Insufficient verifiable evidence for the configured quality target."]
        return QualityReport(score, score >= self.target, {
            "execution": execution_score,
            "evidence": evidence_score,
            "error_free": error_score,
        }, issues)

    def evaluate_mission(self, step_reports: List[QualityReport]) -> QualityReport:
        if not step_reports:
            return QualityReport(0.0, False, {}, ["No completed steps."])
        score = round(sum(r.score for r in step_reports) / len(step_reports), 2)
        issues = [i for r in step_reports for i in r.issues]
        return QualityReport(score, all(r.passed for r in step_reports) and score >= self.target,
                             {"steps_average": score}, issues)
