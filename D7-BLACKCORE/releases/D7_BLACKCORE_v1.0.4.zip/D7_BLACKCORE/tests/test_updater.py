from pathlib import Path
import hashlib, zipfile
from blackcore.updater import UpdateInfo, UpdateManager, is_newer
from blackcore.config import Settings


def test_version_compare():
    assert is_newer("0.2.1-alpha","0.2.0-alpha")
    assert not is_newer("0.2.0-alpha","0.2.0-alpha")
    assert not is_newer("0.1.9","0.2.0-alpha")


def test_manifest_validation():
    i=UpdateInfo.from_dict({"version":"1.0.0","download_url":"https://example.com/a.zip","sha256":"a"*64})
    assert i.version=="1.0.0"


def test_updater_requires_url(tmp_path):
    s=Settings(data_dir=str(tmp_path/"data"),update_manifest_url="")
    u=UpdateManager(s); available,msg,info=u.check()
    assert not available and info is None and "No update" in msg


def test_safe_extract_rejects_zip_slip(tmp_path):
    z=tmp_path/"bad.zip"
    with zipfile.ZipFile(z,"w") as f: f.writestr("../evil.txt","x")
    try:
        UpdateManager._safe_extract(z,tmp_path/"out")
        assert False, "zip slip should fail"
    except ValueError:
        pass
