from pathlib import Path
from types import SimpleNamespace
from blackcore.memory import MemoryStore
from blackcore.quality import QualityEngine
from blackcore.models import StepResult, Evidence, MissionStatus
from blackcore.planner import Planner
from blackcore.safety import SafetyPolicy
from blackcore.system_operator import SystemOperator


def test_memory_roundtrip(tmp_path):
    m=MemoryStore(tmp_path/"m.db"); m.remember("taste","video",{"pace":"fast"},0.9)
    assert m.recall("taste","video")["pace"]=="fast"


def test_quality_evidence_gate():
    q=QualityEngine(95)
    r=q.evaluate_step(StepResult(True,"ok",[Evidence("a","1"),Evidence("b","2")]))
    assert r.passed and r.score==100


def test_safety():
    s=SafetyPolicy()
    assert s.classify("publish video").value=="APPROVAL"
    assert s.classify("disable defender").value=="BLOCKED"
    assert s.classify("open_url").value=="SAFE"


def test_planner_search():
    m=Planner().plan("دور لي عن فرص ربح في اليوتيوب")
    assert len(m.steps)>=1
    assert m.steps[0].action=="search_web"


def test_operator_files(tmp_path):
    op=SystemOperator(tmp_path/"w")
    p=tmp_path/"x"/"a.txt"
    r=op.execute("write_text",path=str(p),text="hello")
    assert r.ok
    r2=op.execute("read_text",path=str(p))
    assert r2.ok and r2.data["text"]=="hello"

def test_memory_corruption_is_preserved_and_rebuilt(tmp_path):
    p=tmp_path/"broken.db"; p.write_bytes(b"not-a-sqlite-db")
    m=MemoryStore(p)
    assert m.recovered_from is not None
    assert Path(m.recovered_from).exists()
    m.remember("recovery","ok",True)
    assert m.recall("recovery","ok") is True


def test_arabic_local_file_fast_path():
    from blackcore.planner import Planner
    mission=Planner().plan('أنشئ مجلد على سطح المكتب باسم BLACKCORE_TEST، وداخله ملف result.txt واكتب فيه: D7 BLACKCORE WORKS. بعد ذلك تحقق من المحتوى.')
    assert [s.action for s in mission.steps[:3]] == ['system:create_folder','system:write_text','system:read_text']
    assert mission.steps[1].args['text'] == 'D7 BLACKCORE WORKS'
    assert mission.steps[1].args['path'].endswith(r'BLACKCORE_TEST\result.txt')
