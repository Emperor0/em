from pathlib import Path
from blackcore.desktop_operator import DesktopOperator
from blackcore.audit import AuditLog
from blackcore.recovery import RecoveryManager
from blackcore.departments import DepartmentHub
from blackcore.models import StepResult

class FakeSwarm:
    def run_council(self,goal,roles): return StepResult(True,'ok',data={'roles':roles,'goal':goal})

def test_audit(tmp_path):
    a=AuditLog(tmp_path/'audit.jsonl'); a.write('x',value=1); rows=a.tail(); assert rows[-1]['event']=='x'

def test_recovery_roundtrip(tmp_path):
    p=tmp_path/'a.txt'; p.write_text('one')
    r=RecoveryManager(tmp_path/'data'); cp=r.checkpoint_file(str(p)); assert cp.ok
    p.write_text('two'); rr=r.restore(cp.data['backup'] if False else cp.evidence[0].value); assert rr.ok; assert p.read_text()=='one'

def test_departments():
    d=DepartmentHub(FakeSwarm()); r=d.run('developer','build'); assert r.ok and 'Architect' in r.data['roles']

def test_desktop_constructs(tmp_path):
    d=DesktopOperator(tmp_path); assert d.shots.exists()
