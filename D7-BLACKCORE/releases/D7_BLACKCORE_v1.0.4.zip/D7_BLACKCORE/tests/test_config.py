from blackcore.config import Settings

def test_settings_defaults():
    s=Settings()
    assert s.quality_target==95.0
    assert s.default_mode=="ELITE"
    assert s.llm_base_url.startswith("http")

def test_corrupt_settings_fall_back_and_preserve_backup(tmp_path):
    p=tmp_path/"settings.json"; p.write_text("{broken",encoding="utf-8")
    s=Settings.load(p)
    assert s.quality_target==95.0
    assert list(tmp_path.glob("settings.json.corrupt.*.bak"))
