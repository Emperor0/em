from blackcore.config import Settings

def test_new_settings_have_updater_defaults(tmp_path):
    s=Settings(data_dir=str(tmp_path/"data"))
    assert s.update_channel=="alpha"
    assert s.self_heal_enabled is True
    assert s.max_browser_retries>=1

def test_opencode_defaults(tmp_path):
    s=Settings(data_dir=str(tmp_path/'data'))
    assert s.llm_base_url == 'http://127.0.0.1:8082'
    assert s.llm_provider_type == 'auto'
    assert s.llm_auto_start is True
