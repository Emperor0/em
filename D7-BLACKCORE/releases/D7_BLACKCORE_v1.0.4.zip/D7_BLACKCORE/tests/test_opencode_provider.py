import json
from unittest.mock import patch
from blackcore.llm import LLMProvider

class FakeResponse:
    def __init__(self, obj, status=200):
        self.obj=obj; self.status=status
    def __enter__(self): return self
    def __exit__(self,*a): pass
    def read(self): return json.dumps(self.obj).encode()

def test_legacy_v1_is_normalized_for_opencode():
    p=LLMProvider('http://127.0.0.1:8082/v1', auto_start=False)
    assert p.origin_url == 'http://127.0.0.1:8082'

def test_opencode_health_detection():
    def fake(req, timeout=0):
        assert req.full_url.endswith('/global/health')
        return FakeResponse({'healthy':True,'version':'1.18.21'})
    with patch('urllib.request.urlopen', fake):
        p=LLMProvider('http://127.0.0.1:8082', auto_start=False)
        assert p.available(force=True)
        assert p.detected_type == 'opencode'
        assert p.server_version == '1.18.21'

def test_opencode_chat_session_and_message():
    calls=[]
    def fake(req, timeout=0):
        calls.append(req.full_url)
        if req.full_url.endswith('/global/health'):
            return FakeResponse({'healthy':True,'version':'1.18.21'})
        if req.full_url.endswith('/session'):
            return FakeResponse({'id':'ses_123'})
        if req.full_url.endswith('/session/ses_123/message'):
            payload=json.loads(req.data.decode())
            assert payload['system']=='sys'
            assert payload['parts'][0]['text']=='hello'
            return FakeResponse({'info':{},'parts':[{'type':'text','text':'world'}]})
        raise AssertionError(req.full_url)
    with patch('urllib.request.urlopen', fake):
        p=LLMProvider('http://127.0.0.1:8082', auto_start=False)
        assert p.chat('sys','hello') == 'world'
        assert any(x.endswith('/session/ses_123/message') for x in calls)
