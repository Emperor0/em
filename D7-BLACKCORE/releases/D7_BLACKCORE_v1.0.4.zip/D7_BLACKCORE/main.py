from __future__ import annotations
import sys, traceback
from datetime import datetime, timezone
from PySide6.QtWidgets import QApplication
from blackcore import Settings, Blackcore
from ui.main_window import MainWindow


def install_crash_logger(settings):
    log_dir=settings.expanded_data_dir()/"logs"; log_dir.mkdir(parents=True,exist_ok=True)
    crash=log_dir/"crash.log"
    default_hook=sys.excepthook
    def hook(exc_type, exc, tb):
        try:
            with crash.open("a",encoding="utf-8") as f:
                f.write("\n=== "+datetime.now(timezone.utc).isoformat()+" ===\n")
                traceback.print_exception(exc_type,exc,tb,file=f)
        finally:
            default_hook(exc_type,exc,tb)
    sys.excepthook=hook


def main():
    settings=Settings.load(); settings.ensure_dirs(); install_crash_logger(settings); core=Blackcore(settings)
    app=QApplication(sys.argv); app.setApplicationName("D7 BLACKCORE")
    w=MainWindow(core); w.show()
    code=app.exec(); core.browser.close(); raise SystemExit(code)

if __name__ == "__main__": main()
