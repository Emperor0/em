@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo BLACKCORE environment not installed yet. Run INSTALL_AND_RUN.bat first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" "%~dp0tools\self_test.py"
pause
